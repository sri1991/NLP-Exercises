/**
 * API service for communicating with the backend
 */

// Base API URL - adjust as needed for your environment
const API_BASE_URL = 'http://localhost:8000/api';

// Types based on backend models
export interface PredictionRequest {
  commodity: string;
  days: number;
  include_explanations: boolean;
  include_raw_data: boolean;
}

export interface PricePoint {
  date: string;
  price: number;
  confidence_lower: number | null;
  confidence_upper: number | null;
}

export interface FeatureImportance {
  feature: string;
  importance: number;
  direction: string;
}

export interface PredictionResponse {
  commodity: string;
  current_price: number;
  predictions: PricePoint[];
  explanation: string | null;
  feature_importance: FeatureImportance[] | null;
  raw_data: any | null;
  generated_at: string;
}

/**
 * Get list of available commodities
 */
export const getCommodities = async (): Promise<string[]> => {
  try {
    const response = await fetch(`${API_BASE_URL}/commodities`);
    
    if (!response.ok) {
      throw new Error(`Failed to fetch commodities: ${response.statusText}`);
    }
    
    return await response.json();
  } catch (error) {
    console.error('Error fetching commodities:', error);
    // Return default commodities in case of error
    return ["steel", "gold", "silver", "crude_oil", "natural_gas", "copper", "aluminum"];
  }
};

/**
 * Get price predictions for a commodity
 */
export const getPredictions = async (request: PredictionRequest): Promise<PredictionResponse> => {
  try {
    const response = await fetch(`${API_BASE_URL}/predict`, {
      method: 'POST',
      headers: {
        'Content-Type': 'application/json',
      },
      body: JSON.stringify(request),
    });
    
    if (!response.ok) {
      throw new Error(`Failed to fetch predictions: ${response.statusText}`);
    }
    
    return await response.json();
  } catch (error) {
    console.error('Error fetching predictions:', error);
    throw error;
  }
};
