import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Separator } from "@/components/ui/separator";
import { Download, FileText, Database, Code } from "lucide-react";
import { useToast } from "@/hooks/use-toast";

export const ExportOptions = () => {
  const { toast } = useToast();

  const handleExport = (format: string) => {
    toast({
      title: "Export Started",
      description: `Generating ${format.toUpperCase()} report with latest predictions and analysis.`,
    });
    
    // Simulate export delay
    setTimeout(() => {
      toast({
        title: "Export Complete",
        description: `Your ${format.toUpperCase()} report has been downloaded successfully.`,
      });
    }, 2000);
  };

  return (
    <Card className="bg-gradient-card shadow-card border-border">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Download className="h-5 w-5 text-primary-glow" />
          <span className="text-primary-glow">Export & Reports</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Prediction Reports */}
        <div className="space-y-3">
          <h4 className="font-semibold text-sm">Prediction Reports</h4>
          <div className="grid grid-cols-1 gap-3">
            <Button
              variant="outline"
              className="justify-start h-auto p-4 bg-secondary/20 hover:bg-secondary/40 border-border transition-all duration-200"
              onClick={() => handleExport('pdf')}
            >
              <div className="flex items-center space-x-3">
                <FileText className="h-5 w-5 text-destructive" />
                <div className="text-left">
                  <div className="font-semibold">PDF Report</div>
                  <div className="text-xs text-muted-foreground">
                    Complete analysis with charts and explanations
                  </div>
                </div>
              </div>
            </Button>
            
            <Button
              variant="outline"
              className="justify-start h-auto p-4 bg-secondary/20 hover:bg-secondary/40 border-border transition-all duration-200"
              onClick={() => handleExport('csv')}
            >
              <div className="flex items-center space-x-3">
                <Database className="h-5 w-5 text-accent" />
                <div className="text-left">
                  <div className="font-semibold">CSV Data</div>
                  <div className="text-xs text-muted-foreground">
                    Raw prediction data and historical prices
                  </div>
                </div>
              </div>
            </Button>
            
            <Button
              variant="outline"
              className="justify-start h-auto p-4 bg-secondary/20 hover:bg-secondary/40 border-border transition-all duration-200"
              onClick={() => handleExport('json')}
            >
              <div className="flex items-center space-x-3">
                <Code className="h-5 w-5 text-primary-glow" />
                <div className="text-left">
                  <div className="font-semibold">JSON API</div>
                  <div className="text-xs text-muted-foreground">
                    Structured data for API integration
                  </div>
                </div>
              </div>
            </Button>
          </div>
        </div>

        <Separator className="bg-border" />

        {/* Quick Actions */}
        <div className="space-y-3">
          <h4 className="font-semibold text-sm">Quick Actions</h4>
          <div className="grid grid-cols-2 gap-3">
            <Button
              size="sm"
              variant="secondary"
              className="bg-secondary/30 hover:bg-secondary/50 transition-all duration-200"
              onClick={() => handleExport('summary')}
            >
              Export Summary
            </Button>
            <Button
              size="sm"
              variant="secondary"
              className="bg-secondary/30 hover:bg-secondary/50 transition-all duration-200"
              onClick={() => handleExport('chart')}
            >
              Save Charts
            </Button>
          </div>
        </div>

        <Separator className="bg-border" />

        {/* Report Details */}
        <div className="p-3 bg-secondary/20 rounded border border-border">
          <h5 className="font-semibold text-xs mb-2">Report Contents</h5>
          <ul className="text-xs text-muted-foreground space-y-1">
            <li>• Current commodity prices and predictions</li>
            <li>• Confidence intervals and accuracy metrics</li>
            <li>• Feature importance analysis (SHAP values)</li>
            <li>• Market sentiment and news analysis</li>
            <li>• Historical performance data</li>
            <li>• Model methodology and parameters</li>
          </ul>
        </div>

        {/* Scheduled Reports */}
        <div className="space-y-2">
          <div className="flex justify-between items-center">
            <h4 className="font-semibold text-sm">Scheduled Reports</h4>
            <Button size="sm" variant="ghost" className="text-primary-glow hover:bg-primary/10">
              Configure
            </Button>
          </div>
          <div className="text-xs text-muted-foreground p-3 bg-secondary/10 rounded border border-border">
            Set up automated daily, weekly, or monthly reports delivered to your email.
          </div>
        </div>
      </CardContent>
    </Card>
  );
};