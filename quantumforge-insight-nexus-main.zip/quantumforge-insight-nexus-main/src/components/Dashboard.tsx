import { useState } from "react";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { CommoditySelector } from "./CommoditySelector";
import { PredictionPanel } from "./PredictionPanel";
import { Beaker } from "lucide-react";

export const Dashboard = () => {
  const [selectedCommodity, setSelectedCommodity] = useState<string>("steel");

  const handleCommodityChange = (commodity: string) => {
    setSelectedCommodity(commodity);
  };

  return (
    <div className="min-h-screen bg-background p-6">
      {/* Header */}
      <div className="mb-8">
        <h1 className="text-4xl font-bold bg-gradient-primary bg-clip-text text-transparent mb-2">
          QuantumForge
        </h1>
        <p className="text-muted-foreground text-lg">
          Advanced Commodity Price Prediction Platform
        </p>
      </div>

      {/* Status Banner */}
      <div className="mb-8 p-4 bg-secondary/30 rounded-lg border border-border flex items-center">
        <Beaker className="h-5 w-5 mr-2 text-primary-glow" />
        <p className="text-sm">
          <span className="font-medium">API Integration Mode:</span>{" "}
          <span className="text-muted-foreground">Using the backend API to fetch real-time commodity price predictions.</span>
        </p>
      </div>

      {/* Main Content Grid */}
      <div className="grid grid-cols-1 lg:grid-cols-4 gap-6 mb-8">
        {/* Left Column - Controls */}
        <div className="space-y-6">
          <Card className="bg-gradient-card shadow-card border-border">
            <CardHeader>
              <CardTitle className="text-primary-glow">Select Commodity</CardTitle>
            </CardHeader>
            <CardContent>
              <CommoditySelector onCommodityChange={handleCommodityChange} />
            </CardContent>
          </Card>
        </div>

        {/* Right Column - Prediction Output (spans 3 columns) */}
        <div className="lg:col-span-3">
          <PredictionPanel commodity={selectedCommodity} />
        </div>
      </div>
    </div>
  );
};