import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { ScrollArea } from "@/components/ui/scroll-area";
import { ExternalLink, TrendingUp, TrendingDown, Minus } from "lucide-react";

interface NewsItem {
  id: string;
  headline: string;
  source: string;
  timestamp: string;
  sentiment: number;
  url: string;
  summary: string;
}

const newsData: NewsItem[] = [
  {
    id: '1',
    headline: 'Global Steel Demand Surges as Infrastructure Projects Accelerate',
    source: 'Steel Industry Today',
    timestamp: '2 hours ago',
    sentiment: 0.8,
    url: '#',
    summary: 'Major infrastructure investments driving unprecedented demand for steel products worldwide.'
  },
  {
    id: '2',
    headline: 'Iron Ore Prices Hit 3-Month High Amid Supply Constraints',
    source: 'Commodity News Network',
    timestamp: '4 hours ago',
    sentiment: 0.6,
    url: '#',
    summary: 'Mining disruptions in Australia and Brazil continue to impact global iron ore supply chains.'
  },
  {
    id: '3',
    headline: 'USD Strengthens Against Major Currencies, Impacting Commodity Exports',
    source: 'Financial Markets Daily',
    timestamp: '6 hours ago',
    sentiment: -0.3,
    url: '#',
    summary: 'Stronger dollar making US commodity exports less competitive in international markets.'
  },
  {
    id: '4',
    headline: 'China Announces New Infrastructure Spending Package Worth $2.3T',
    source: 'Asia Economic Review',
    timestamp: '8 hours ago',
    sentiment: 0.9,
    url: '#',
    summary: 'Massive infrastructure investment expected to boost demand for steel, cement, and copper.'
  },
  {
    id: '5',
    headline: 'Energy Costs Drop 15% as Natural Gas Prices Stabilize',
    source: 'Energy Market Insights',
    timestamp: '12 hours ago',
    sentiment: 0.4,
    url: '#',
    summary: 'Lower energy costs providing relief to energy-intensive manufacturing sectors.'
  },
  {
    id: '6',
    headline: 'Trade Tensions Ease as New Bilateral Agreement Reached',
    source: 'Global Trade Monitor',
    timestamp: '1 day ago',
    sentiment: 0.5,
    url: '#',
    summary: 'Reduced trade barriers expected to improve commodity flow between major economies.'
  }
];

const getSentimentColor = (sentiment: number) => {
  if (sentiment > 0.3) return 'text-accent';
  if (sentiment < -0.3) return 'text-destructive';
  return 'text-muted-foreground';
};

const getSentimentIcon = (sentiment: number) => {
  if (sentiment > 0.3) return <TrendingUp className="h-3 w-3" />;
  if (sentiment < -0.3) return <TrendingDown className="h-3 w-3" />;
  return <Minus className="h-3 w-3" />;
};

const getSentimentLabel = (sentiment: number) => {
  if (sentiment > 0.6) return 'Very Bullish';
  if (sentiment > 0.3) return 'Bullish';
  if (sentiment > -0.3) return 'Neutral';
  if (sentiment > -0.6) return 'Bearish';
  return 'Very Bearish';
};

export const NewsFeed = () => {
  return (
    <Card className="bg-gradient-card shadow-card border-border">
      <CardHeader>
        <CardTitle className="flex items-center justify-between">
          <span className="text-primary-glow">Market News & Sentiment</span>
          <Badge variant="outline" className="text-xs">
            Live Feed
          </Badge>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <ScrollArea className="h-96">
          <div className="space-y-4">
            {newsData.map((news) => (
              <div
                key={news.id}
                className="p-4 bg-secondary/20 rounded-lg border border-border hover:bg-secondary/30 transition-all duration-200 group"
              >
                <div className="flex items-start justify-between mb-2">
                  <div className="flex items-center space-x-2">
                    <Badge 
                      variant="outline" 
                      className={`text-xs ${getSentimentColor(news.sentiment)}`}
                    >
                      <div className="flex items-center space-x-1">
                        {getSentimentIcon(news.sentiment)}
                        <span>{getSentimentLabel(news.sentiment)}</span>
                      </div>
                    </Badge>
                    <span className="text-xs text-muted-foreground">
                      {news.timestamp}
                    </span>
                  </div>
                  <ExternalLink className="h-4 w-4 text-muted-foreground opacity-0 group-hover:opacity-100 transition-opacity cursor-pointer" />
                </div>
                
                <h4 className="font-semibold text-sm mb-2 leading-tight">
                  {news.headline}
                </h4>
                
                <p className="text-xs text-muted-foreground mb-3 leading-relaxed">
                  {news.summary}
                </p>
                
                <div className="flex items-center justify-between">
                  <span className="text-xs font-medium text-primary-glow">
                    {news.source}
                  </span>
                  <div className="flex items-center space-x-2">
                    <div className="text-xs text-muted-foreground">
                      Sentiment Score:
                    </div>
                    <div className={`text-xs font-semibold ${getSentimentColor(news.sentiment)}`}>
                      {news.sentiment > 0 ? '+' : ''}{(news.sentiment * 100).toFixed(0)}%
                    </div>
                  </div>
                </div>
              </div>
            ))}
          </div>
        </ScrollArea>
        
        <div className="mt-4 p-3 bg-secondary/20 rounded border border-border">
          <div className="flex justify-between items-center text-sm">
            <span className="text-muted-foreground">Overall Market Sentiment:</span>
            <div className="flex items-center space-x-2">
              <TrendingUp className="h-4 w-4 text-accent" />
              <span className="font-semibold text-accent">+62% Bullish</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
};