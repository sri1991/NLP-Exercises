import { useState, useEffect } from "react";
import { Check, ChevronDown, Loader2 } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import {
  Command,
  CommandEmpty,
  CommandGroup,
  CommandInput,
  CommandItem,
  CommandList,
} from "@/components/ui/command";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { getCommodities } from "@/services/api";

// Commodity categories mapping
const categoryMap: Record<string, string> = {
  "steel": "Metals",
  "gold": "Metals",
  "silver": "Metals",
  "copper": "Metals",
  "aluminum": "Metals",
  "iron-ore": "Metals",
  "cement": "Construction",
  "concrete": "Construction",
  "lumber": "Construction",
  "crude_oil": "Energy",
  "natural_gas": "Energy",
  "coal": "Energy"
};

interface CommoditySelectorProps {
  onCommodityChange?: (commodity: string) => void;
}

export const CommoditySelector = ({ onCommodityChange }: CommoditySelectorProps) => {
  const [open, setOpen] = useState(false);
  const [value, setValue] = useState("steel");
  const [commodities, setCommodities] = useState<Array<{value: string, label: string, category: string}>>([]);
  const [isLoading, setIsLoading] = useState(true);

  // Fetch commodities from API on component mount
  useEffect(() => {
    const fetchCommodities = async () => {
      try {
        setIsLoading(true);
        const commodityList = await getCommodities();
        
        // Transform the commodity list into the format we need
        const formattedCommodities = commodityList.map(commodity => ({
          value: commodity,
          label: commodity.split('_').map(word => word.charAt(0).toUpperCase() + word.slice(1)).join(' '),
          category: categoryMap[commodity] || "Other"
        }));
        
        setCommodities(formattedCommodities);
      } catch (error) {
        console.error("Failed to fetch commodities:", error);
      } finally {
        setIsLoading(false);
      }
    };
    
    fetchCommodities();
  }, []);
  
  // Notify parent component when commodity changes
  useEffect(() => {
    if (onCommodityChange) {
      onCommodityChange(value);
    }
  }, [value, onCommodityChange]);

  return (
    <Popover open={open} onOpenChange={setOpen}>
      <PopoverTrigger asChild>
        <Button
          variant="outline"
          role="combobox"
          aria-expanded={open}
          className="w-full justify-between bg-secondary/50 border-border hover:bg-secondary transition-all duration-200"
          disabled={isLoading}
        >
          {isLoading ? (
            <>
              <span>Loading commodities...</span>
              <Loader2 className="ml-2 h-4 w-4 shrink-0 animate-spin" />
            </>
          ) : (
            <>
              {value
                ? commodities.find((commodity) => commodity.value === value)?.label
                : "Select commodity..."}
              <ChevronDown className="ml-2 h-4 w-4 shrink-0 opacity-50" />
            </>
          )}
        </Button>
      </PopoverTrigger>
      <PopoverContent className="w-full p-0 bg-popover border-border shadow-elegant">
        <Command className="bg-transparent">
          <CommandInput placeholder="Search commodities..." className="border-0" />
          <CommandList className="max-h-64">
            <CommandEmpty>No commodity found.</CommandEmpty>
            {isLoading ? (
              <div className="flex items-center justify-center py-6">
                <Loader2 className="h-6 w-6 animate-spin text-primary" />
                <span className="ml-2 text-sm text-muted-foreground">Loading commodities...</span>
              </div>
            ) : (
              // Group commodities by category
              [...new Set(commodities.map(c => c.category))].map((category) => (
                <CommandGroup key={category} heading={category} className="text-muted-foreground">
                  {commodities
                    .filter((commodity) => commodity.category === category)
                    .map((commodity) => (
                      <CommandItem
                        key={commodity.value}
                        value={commodity.value}
                        onSelect={(currentValue) => {
                          setValue(currentValue === value ? "" : currentValue);
                          setOpen(false);
                        }}
                        className="cursor-pointer hover:bg-secondary/50 transition-colors"
                      >
                        <Check
                          className={cn(
                            "mr-2 h-4 w-4",
                            value === commodity.value ? "opacity-100 text-accent" : "opacity-0"
                          )}
                        />
                        {commodity.label}
                      </CommandItem>
                    ))}
                </CommandGroup>
              ))
            )}
          </CommandList>
        </Command>
      </PopoverContent>
    </Popover>
  );
};