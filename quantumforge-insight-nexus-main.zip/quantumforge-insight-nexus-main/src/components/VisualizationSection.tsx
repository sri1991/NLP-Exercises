import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { 
  LineChart, 
  Line, 
  XAxis, 
  YAxis, 
  CartesianGrid, 
  Tooltip, 
  ResponsiveContainer,
  BarChart,
  Bar,
  Area,
  AreaChart
} from "recharts";
import { TrendingUp, BarChart as BarChartIcon, Activity } from "lucide-react";

const historicalData = [
  { date: '2024-01-01', price: 4100, predicted: null, lower: null, upper: null },
  { date: '2024-01-05', price: 4120, predicted: null, lower: null, upper: null },
  { date: '2024-01-10', price: 4200, predicted: null, lower: null, upper: null },
  { date: '2024-01-15', price: 4250, predicted: null, lower: null, upper: null },
  { date: '2024-01-20', price: 4280, predicted: 4320, lower: 4200, upper: 4440 },
  { date: '2024-01-25', price: null, predicted: 4450, lower: 4320, upper: 4580 },
  { date: '2024-01-30', price: null, predicted: 4580, lower: 4440, upper: 4720 },
  { date: '2024-02-05', price: null, predicted: 4680, lower: 4540, upper: 4820 },
  { date: '2024-02-10', price: null, predicted: 4720, lower: 4580, upper: 4860 },
  { date: '2024-02-15', price: null, predicted: 4780, lower: 4630, upper: 4930 },
];

const featureImportanceData = [
  { factor: 'Iron Ore Prices', importance: 34 },
  { factor: 'USD Exchange', importance: 28 },
  { factor: 'Infrastructure', importance: 22 },
  { factor: 'Energy Costs', importance: 16 },
  { factor: 'Supply Chain', importance: 12 },
  { factor: 'Trade Policy', importance: 8 },
];

const sentimentData = [
  { date: '2024-01-01', sentiment: 0.2 },
  { date: '2024-01-05', sentiment: 0.4 },
  { date: '2024-01-10', sentiment: 0.6 },
  { date: '2024-01-15', sentiment: 0.3 },
  { date: '2024-01-20', sentiment: 0.7 },
  { date: '2024-01-25', sentiment: 0.8 },
  { date: '2024-01-30', sentiment: 0.6 },
];

export const VisualizationSection = () => {
  return (
    <Card className="bg-gradient-card shadow-card border-border">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Activity className="h-5 w-5 text-primary-glow" />
          <span className="text-primary-glow">Market Analytics</span>
        </CardTitle>
      </CardHeader>
      <CardContent>
        <Tabs defaultValue="timeseries" className="w-full">
          <TabsList className="grid w-full grid-cols-3 bg-secondary/30">
            <TabsTrigger value="timeseries" className="flex items-center space-x-2">
              <TrendingUp className="h-4 w-4" />
              <span>Price Forecast</span>
            </TabsTrigger>
            <TabsTrigger value="features" className="flex items-center space-x-2">
              <BarChartIcon className="h-4 w-4" />
              <span>Feature Impact</span>
            </TabsTrigger>
            <TabsTrigger value="sentiment" className="flex items-center space-x-2">
              <Activity className="h-4 w-4" />
              <span>Market Sentiment</span>
            </TabsTrigger>
          </TabsList>

          <TabsContent value="timeseries" className="mt-6">
            <div className="space-y-4">
              <div className="flex justify-between items-center">
                <h4 className="font-semibold">Steel Price Forecast with Confidence Bands</h4>
                <div className="flex space-x-4 text-sm">
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-primary rounded-full"></div>
                    <span>Historical</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-accent rounded-full"></div>
                    <span>Predicted</span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-primary-glow/30 rounded-full"></div>
                    <span>95% Confidence</span>
                  </div>
                </div>
              </div>
              <ResponsiveContainer width="100%" height={400}>
                <LineChart data={historicalData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis 
                    dataKey="date" 
                    stroke="hsl(var(--muted-foreground))"
                    tick={{ fontSize: 12 }}
                  />
                  <YAxis 
                    stroke="hsl(var(--muted-foreground))"
                    tick={{ fontSize: 12 }}
                    domain={['dataMin - 100', 'dataMax + 100']}
                  />
                  <Tooltip 
                    contentStyle={{
                      backgroundColor: 'hsl(var(--popover))',
                      borderColor: 'hsl(var(--border))',
                      borderRadius: '8px',
                    }}
                  />
                  <Area
                    dataKey="upper"
                    fill="hsl(var(--primary-glow) / 0.1)"
                    stroke="none"
                  />
                  <Area
                    dataKey="lower"
                    fill="hsl(var(--background))"
                    stroke="none"
                  />
                  <Line
                    type="monotone"
                    dataKey="price"
                    stroke="hsl(var(--primary))"
                    strokeWidth={3}
                    dot={{ fill: 'hsl(var(--primary))', strokeWidth: 2, r: 4 }}
                    connectNulls={false}
                  />
                  <Line
                    type="monotone"
                    dataKey="predicted"
                    stroke="hsl(var(--accent))"
                    strokeWidth={2}
                    strokeDasharray="5 5"
                    dot={{ fill: 'hsl(var(--accent))', strokeWidth: 2, r: 3 }}
                    connectNulls={false}
                  />
                </LineChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>

          <TabsContent value="features" className="mt-6">
            <div className="space-y-4">
              <h4 className="font-semibold">Feature Importance Analysis</h4>
              <ResponsiveContainer width="100%" height={350}>
                <BarChart data={featureImportanceData} layout="horizontal">
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis 
                    type="number" 
                    stroke="hsl(var(--muted-foreground))"
                    tick={{ fontSize: 12 }}
                  />
                  <YAxis 
                    type="category" 
                    dataKey="factor" 
                    stroke="hsl(var(--muted-foreground))"
                    tick={{ fontSize: 12 }}
                    width={100}
                  />
                  <Tooltip 
                    contentStyle={{
                      backgroundColor: 'hsl(var(--popover))',
                      borderColor: 'hsl(var(--border))',
                      borderRadius: '8px',
                    }}
                  />
                  <Bar 
                    dataKey="importance" 
                    fill="hsl(var(--primary))"
                    radius={[0, 4, 4, 0]}
                  />
                </BarChart>
              </ResponsiveContainer>
            </div>
          </TabsContent>

          <TabsContent value="sentiment" className="mt-6">
            <div className="space-y-4">
              <h4 className="font-semibold">Market Sentiment Trend</h4>
              <ResponsiveContainer width="100%" height={300}>
                <AreaChart data={sentimentData}>
                  <CartesianGrid strokeDasharray="3 3" stroke="hsl(var(--border))" />
                  <XAxis 
                    dataKey="date" 
                    stroke="hsl(var(--muted-foreground))"
                    tick={{ fontSize: 12 }}
                  />
                  <YAxis 
                    stroke="hsl(var(--muted-foreground))"
                    tick={{ fontSize: 12 }}
                    domain={[-1, 1]}
                  />
                  <Tooltip 
                    contentStyle={{
                      backgroundColor: 'hsl(var(--popover))',
                      borderColor: 'hsl(var(--border))',
                      borderRadius: '8px',
                    }}
                    formatter={(value: number) => [
                      value > 0 ? `+${(value * 100).toFixed(1)}% Bullish` : `${(value * 100).toFixed(1)}% Bearish`,
                      'Sentiment'
                    ]}
                  />
                  <Area
                    type="monotone"
                    dataKey="sentiment"
                    stroke="hsl(var(--accent))"
                    fill="hsl(var(--accent) / 0.3)"
                    strokeWidth={2}
                  />
                </AreaChart>
              </ResponsiveContainer>
              <div className="flex justify-between text-sm text-muted-foreground">
                <span>Bearish (-100%)</span>
                <span>Neutral (0%)</span>
                <span>Bullish (+100%)</span>
              </div>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  );
};