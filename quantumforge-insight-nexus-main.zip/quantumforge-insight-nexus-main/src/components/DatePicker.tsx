import * as React from "react";
import { format } from "date-fns";
import { CalendarIcon } from "lucide-react";
import { cn } from "@/lib/utils";
import { Button } from "@/components/ui/button";
import { Calendar } from "@/components/ui/calendar";
import {
  Popover,
  PopoverContent,
  PopoverTrigger,
} from "@/components/ui/popover";
import { Label } from "@/components/ui/label";
import { Slider } from "@/components/ui/slider";

export const DatePicker = () => {
  const [startDate, setStartDate] = React.useState<Date>(new Date());
  const [forecastDays, setForecastDays] = React.useState([30]);
  
  const endDate = new Date(startDate);
  endDate.setDate(startDate.getDate() + forecastDays[0]);

  return (
    <div className="space-y-6">
      {/* Start Date Picker */}
      <div className="space-y-2">
        <Label className="text-sm font-medium">Start Date</Label>
        <Popover>
          <PopoverTrigger asChild>
            <Button
              variant="outline"
              className={cn(
                "w-full justify-start text-left font-normal bg-secondary/50 border-border hover:bg-secondary transition-all duration-200",
                !startDate && "text-muted-foreground"
              )}
            >
              <CalendarIcon className="mr-2 h-4 w-4" />
              {startDate ? format(startDate, "PPP") : <span>Pick start date</span>}
            </Button>
          </PopoverTrigger>
          <PopoverContent className="w-auto p-0 bg-popover border-border shadow-elegant" align="start">
            <Calendar
              mode="single"
              selected={startDate}
              onSelect={(date) => date && setStartDate(date)}
              initialFocus
              className="p-3 pointer-events-auto"
            />
          </PopoverContent>
        </Popover>
      </div>

      {/* Forecast Range Slider */}
      <div className="space-y-4">
        <div className="flex justify-between items-center">
          <Label className="text-sm font-medium">Forecast Range</Label>
          <span className="text-sm text-primary-glow font-semibold">
            {forecastDays[0]} days
          </span>
        </div>
        
        <Slider
          value={forecastDays}
          onValueChange={setForecastDays}
          max={60}
          min={1}
          step={1}
          className="w-full"
        />
        
        <div className="flex justify-between text-xs text-muted-foreground">
          <span>1 day</span>
          <span>60 days</span>
        </div>
      </div>

      {/* Date Range Summary */}
      <div className="p-4 bg-secondary/30 rounded-lg border border-border">
        <div className="text-sm space-y-1">
          <div className="flex justify-between">
            <span className="text-muted-foreground">From:</span>
            <span className="font-medium">{format(startDate, "MMM dd, yyyy")}</span>
          </div>
          <div className="flex justify-between">
            <span className="text-muted-foreground">To:</span>
            <span className="font-medium">{format(endDate, "MMM dd, yyyy")}</span>
          </div>
          <div className="flex justify-between pt-2 border-t border-border">
            <span className="text-muted-foreground">Duration:</span>
            <span className="font-medium text-primary-glow">{forecastDays[0]} days</span>
          </div>
        </div>
      </div>
    </div>
  );
};