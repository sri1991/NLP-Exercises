import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Progress } from "@/components/ui/progress";
import { Badge } from "@/components/ui/badge";
import { Brain, BarChart, TrendingUp, Globe } from "lucide-react";

export const ExplainabilityPanel = () => {
  const factors = [
    {
      name: "Iron Ore Prices",
      importance: 0.34,
      impact: "positive",
      change: "+12.5%",
      description: "Rising iron ore costs directly impact steel production",
    },
    {
      name: "USD Exchange Rate",
      importance: 0.28,
      impact: "negative",
      change: "-3.2%",
      description: "Stronger dollar makes exports less competitive",
    },
    {
      name: "Infrastructure Spending",
      importance: 0.22,
      impact: "positive",
      change: "+8.9%",
      description: "Government infrastructure projects boost demand",
    },
    {
      name: "Energy Costs",
      importance: 0.16,
      impact: "positive",
      change: "+5.1%",
      description: "Lower energy prices reduce production costs",
    },
  ];

  const getImpactColor = (impact: string) => {
    return impact === "positive" ? "text-accent" : "text-destructive";
  };

  const getImpactIcon = (impact: string) => {
    return impact === "positive" ? "↗" : "↘";
  };

  return (
    <Card className="bg-gradient-card shadow-card border-border">
      <CardHeader>
        <CardTitle className="flex items-center space-x-2">
          <Brain className="h-5 w-5 text-primary-glow" />
          <span className="text-primary-glow">AI Explainability</span>
        </CardTitle>
      </CardHeader>
      <CardContent className="space-y-6">
        {/* Feature Importance */}
        <div className="space-y-4">
          <div className="flex items-center space-x-2">
            <BarChart className="h-4 w-4 text-muted-foreground" />
            <h4 className="font-semibold">Top Influencing Factors</h4>
          </div>
          
          <div className="space-y-3">
            {factors.map((factor, index) => (
              <div key={index} className="space-y-2">
                <div className="flex justify-between items-center">
                  <span className="text-sm font-medium">{factor.name}</span>
                  <div className="flex items-center space-x-2">
                    <Badge variant="outline" className="text-xs">
                      {(factor.importance * 100).toFixed(1)}%
                    </Badge>
                    <span className={`text-sm font-semibold ${getImpactColor(factor.impact)}`}>
                      {getImpactIcon(factor.impact)} {factor.change}
                    </span>
                  </div>
                </div>
                <Progress value={factor.importance * 100} className="h-2" />
                <p className="text-xs text-muted-foreground">{factor.description}</p>
              </div>
            ))}
          </div>
        </div>

        {/* SHAP Values Summary */}
        <div className="p-4 bg-secondary/30 rounded-lg border border-border">
          <h4 className="font-semibold mb-2 flex items-center">
            <TrendingUp className="h-4 w-4 mr-2 text-primary-glow" />
            SHAP Analysis Summary
          </h4>
          <div className="space-y-2 text-sm">
            <div className="flex justify-between">
              <span className="text-muted-foreground">Positive Contributions:</span>
              <span className="text-accent font-semibold">+15.8%</span>
            </div>
            <div className="flex justify-between">
              <span className="text-muted-foreground">Negative Contributions:</span>
              <span className="text-destructive font-semibold">-5.7%</span>
            </div>
            <div className="flex justify-between pt-2 border-t border-border">
              <span className="font-medium">Net Impact:</span>
              <span className="text-accent font-bold">+10.1%</span>
            </div>
          </div>
        </div>

        {/* AI Generated Summary */}
        <div className="space-y-3">
          <div className="flex items-center space-x-2">
            <Globe className="h-4 w-4 text-muted-foreground" />
            <h4 className="font-semibold">AI Market Analysis</h4>
          </div>
          
          <div className="p-4 bg-gradient-primary/5 rounded-lg border border-primary/10">
            <p className="text-sm text-muted-foreground leading-relaxed">
              Steel prices are expected to rise by 10.1% over the next 30 days, primarily driven by 
              <span className="text-accent font-medium"> increasing iron ore costs (+12.5%)</span> and 
              <span className="text-accent font-medium"> robust infrastructure spending (+8.9%)</span>. 
              While the stronger USD poses some headwinds, the overall market sentiment remains 
              <span className="text-primary-glow font-medium"> bullish</span> with 
              <span className="text-accent font-medium"> 95% confidence</span>.
            </p>
          </div>
        </div>

        {/* Model Transparency */}
        <div className="text-xs text-muted-foreground p-3 bg-secondary/20 rounded border border-border">
          <p className="mb-1">
            <strong>Model:</strong> Ensemble (XGBoost + LSTM + Transformer)
          </p>
          <p className="mb-1">
            <strong>Training Data:</strong> 5 years of historical data (2019-2024)
          </p>
          <p>
            <strong>Last Updated:</strong> 2024-01-15 09:30 UTC
          </p>
        </div>
      </CardContent>
    </Card>
  );
};