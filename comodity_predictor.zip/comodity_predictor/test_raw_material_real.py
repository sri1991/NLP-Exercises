"""
Test script for the raw material agent with real-time data only.
"""
import logging
from datetime import datetime, timedelta
from agents.raw_material import fetch_raw_material_data

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)

def main():
    """Test the raw material agent with real-time data only."""
    # Define test parameters
    today = datetime.now()
    start_date = (today - timedelta(days=30)).strftime("%Y-%m-%d")  # Last 30 days
    end_date = today.strftime("%Y-%m-%d")
    
    date_range = {
        "start": start_date,
        "end": end_date
    }
    
    # Test with a few different commodities
    commodities = ["steel", "copper", "gold", "crude_oil"]
    
    for commodity in commodities:
        logger.info(f"Testing raw material agent for {commodity} from {start_date} to {end_date}")
        
        try:
            # Call the raw material agent
            result = fetch_raw_material_data(commodity, date_range)
            
            # Print the result metadata
            logger.info(f"Raw material agent returned data with source: {result['metadata']['source']}")
            logger.info(f"Raw materials for {commodity}: {result['metadata']['raw_materials']}")
            
            # Check each raw material
            for material in result['metadata']['raw_materials']:
                data = result.get(material, [])
                data_points = len(data)
                logger.info(f"Raw material '{material}': {data_points} data points")
                
                if data_points > 0:
                    logger.info(f"  First data point: {data[0]}")
                    logger.info(f"  Last data point: {data[-1]}")
                else:
                    logger.warning(f"  No data available for {material}")
            
        except Exception as e:
            logger.error(f"Error testing raw material agent for {commodity}: {str(e)}")
    
    return "Testing complete"

if __name__ == "__main__":
    main()
