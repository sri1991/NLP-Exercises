"""
Test script for the agent orchestrator.
"""
import logging
from orchestrator.graph import run_prediction_workflow

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)

def main():
    """Test the agent orchestrator."""
    # Define test parameters
    commodity = "gold"
    days = 30
    
    logger.info(f"Testing prediction workflow for {commodity} with {days} days forecast")
    
    try:
        # Run the prediction workflow
        result = run_prediction_workflow(commodity, days)
        
        # Print the result
        logger.info(f"Workflow completed with current agent: {result['current_agent']}")
        logger.info(f"Errors: {result['errors'] if result['errors'] else 'None'}")
        
        # Check if we have a report
        if result.get('report'):
            logger.info(f"Report generated for {result['report'].get('commodity')}")
            logger.info(f"Current price: {result['report'].get('current_price')}")
            logger.info(f"Number of predictions: {len(result['report'].get('predictions', []))}")
        else:
            logger.info("No report generated")
        
        return result
    except Exception as e:
        logger.error(f"Error testing orchestrator: {str(e)}")
        raise

if __name__ == "__main__":
    main()
