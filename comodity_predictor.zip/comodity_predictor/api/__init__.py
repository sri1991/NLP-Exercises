"""
API package for the Commodity Price Predictor.
"""
