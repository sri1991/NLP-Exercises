"""
API routes for the Commodity Price Predictor.
"""
import random
import os
import logging
from datetime import datetime, timedelta
from typing import List, Dict, Any, Optional
from fastapi import APIRouter, HTTPException, Query
from pydantic import BaseModel, Field

# Configure logging
logger = logging.getLogger(__name__)

router = APIRouter(
    tags=["commodities"],
    responses={
        404: {"description": "Not found"},
        500: {"description": "Internal server error"}
    }
)

class PredictionRequest(BaseModel):
    """Request model for commodity price prediction."""
    commodity: str = Field(
        ..., 
        description="Commodity type to predict prices for",
        example="steel",
        title="Commodity Identifier"
    )
    days: int = Field(
        60, 
        description="Number of days to forecast into the future",
        ge=1, 
        le=365,
        example=60,
        title="Forecast Horizon"
    )
    include_explanations: bool = Field(
        True, 
        description="Whether to include textual explanations and feature importance analysis",
        example=True,
        title="Include Explanations"
    )
    include_raw_data: bool = Field(
        False, 
        description="Whether to include raw data used for predictions (increases response size)",
        example=False,
        title="Include Raw Data"
    )
    
    class Config:
        schema_extra = {
            "example": {
                "commodity": "steel",
                "days": 60,
                "include_explanations": True,
                "include_raw_data": False
            }
        }

class PricePoint(BaseModel):
    """Model for a price data point with confidence intervals."""
    date: datetime = Field(
        ...,
        description="Date of the price prediction",
        example="2025-07-07T07:00:00",
        title="Prediction Date"
    )
    price: float = Field(
        ...,
        description="Predicted price value",
        example=100.0,
        title="Price"
    )
    confidence_lower: Optional[float] = Field(
        None,
        description="Lower bound of the confidence interval",
        example=98.0,
        title="Lower Confidence Bound"
    )
    confidence_upper: Optional[float] = Field(
        None,
        description="Upper bound of the confidence interval",
        example=102.0,
        title="Upper Confidence Bound"
    )
    
    class Config:
        schema_extra = {
            "example": {
                "date": "2025-07-07T07:00:00",
                "price": 100.0,
                "confidence_lower": 98.0,
                "confidence_upper": 102.0
            }
        }

class FeatureImportance(BaseModel):
    """Model for feature importance data showing factors affecting the prediction."""
    feature: str = Field(
        ...,
        description="Name of the feature or factor affecting the price",
        example="Economic Growth",
        title="Feature Name"
    )
    importance: float = Field(
        ...,
        description="Relative importance of this feature (0.0 to 1.0)",
        example=0.4,
        ge=0.0,
        le=1.0,
        title="Importance Score"
    )
    direction: str = Field(
        ...,
        description="Direction of influence: 'positive' means higher feature values increase price, 'negative' means they decrease price",
        example="positive",
        title="Direction of Influence"
    )
    
    class Config:
        schema_extra = {
            "example": {
                "feature": "Economic Growth",
                "importance": 0.4,
                "direction": "positive"
            }
        }

class PredictionResponse(BaseModel):
    """Response model for commodity price prediction with detailed forecast data."""
    commodity: str = Field(
        ...,
        description="Commodity identifier that was predicted",
        example="steel",
        title="Commodity"
    )
    current_price: float = Field(
        ...,
        description="Current market price of the commodity",
        example=100.0,
        title="Current Price"
    )
    predictions: List[PricePoint] = Field(
        ...,
        description="List of price predictions for each day in the forecast horizon",
        title="Price Predictions"
    )
    explanation: Optional[str] = Field(
        None,
        description="Textual explanation of the price forecast and key factors",
        example="Price is expected to increase due to higher demand and limited supply.",
        title="Explanation"
    )
    feature_importance: Optional[List[FeatureImportance]] = Field(
        None,
        description="List of features and their importance in the prediction",
        title="Feature Importance"
    )
    raw_data: Optional[dict] = Field(
        None,
        description="Raw data used for the prediction (only included if requested)",
        title="Raw Data"
    )
    generated_at: datetime = Field(
        default_factory=datetime.now,
        description="Timestamp when the prediction was generated",
        example="2025-07-07T07:08:14",
        title="Generation Timestamp"
    )
    
    class Config:
        schema_extra = {
            "example": {
                "commodity": "steel",
                "current_price": 100.0,
                "predictions": [
                    {"date": "2025-07-07T07:00:00", "price": 100.0, "confidence_lower": 98.0, "confidence_upper": 102.0},
                    {"date": "2025-07-08T07:00:00", "price": 100.5, "confidence_lower": 98.5, "confidence_upper": 102.5}
                ],
                "explanation": "Price is expected to increase due to higher demand and limited supply.",
                "feature_importance": [
                    {"feature": "Economic Growth", "importance": 0.4, "direction": "positive"},
                    {"feature": "Interest Rates", "importance": 0.3, "direction": "negative"}
                ],
                "generated_at": "2025-07-07T07:08:14"
            }
        }

@router.post("/predict", response_model=PredictionResponse,
           summary="Predict commodity prices",
           description="Generate price predictions for the specified commodity over a given time period. Includes confidence intervals and feature importance.",
           response_description="Price prediction data including current price, forecasted prices, and optional explanations",
           status_code=200,
           responses={
               200: {
                   "description": "Successful prediction",
                   "content": {
                       "application/json": {
                           "example": {
                               "commodity": "steel",
                               "current_price": 100.0,
                               "predictions": [
                                   {"date": "2025-07-07T07:00:00", "price": 100.0, "confidence_lower": 98.0, "confidence_upper": 102.0},
                                   {"date": "2025-07-08T07:00:00", "price": 100.5, "confidence_lower": 98.5, "confidence_upper": 102.5}
                               ],
                               "explanation": "Price is expected to increase due to higher demand and limited supply.",
                               "feature_importance": [
                                   {"feature": "Economic Growth", "importance": 0.4, "direction": "positive"},
                                   {"feature": "Interest Rates", "importance": 0.3, "direction": "negative"}
                               ],
                               "generated_at": "2025-07-07T07:08:14"
                           }
                       }
                   }
               },
               422: {"description": "Validation error in request parameters"},
               500: {"description": "Prediction engine failure"}
           })
async def predict_prices(request: PredictionRequest):
    """
    Generate price predictions for the specified commodity.
    
    - **commodity**: The commodity to predict prices for (e.g., steel, gold)
    - **days**: Number of days to forecast (1-365)
    - **include_explanations**: Whether to include textual explanations and feature importance
    - **include_raw_data**: Whether to include raw data used for predictions
    
    Returns a detailed prediction response with confidence intervals.
    """
    try:
        # Use the agent system to generate predictions
        from orchestrator.graph import run_prediction_workflow
        
        logger.info(f"Running prediction workflow for {request.commodity} with {request.days} days forecast")
        
        # Calculate days_back (default to 365 days of historical data)
        days_back = 365
        
        # Run the agent workflow
        result = run_prediction_workflow(
            commodity=request.commodity,
            days_back=days_back,
            forecast_days=request.days
        )
        
        # Check for errors in the workflow
        if result.get("errors", []):
            error_msg = "; ".join(result.get("errors", []))
            logger.error(f"Prediction workflow errors: {error_msg}")
            raise HTTPException(status_code=500, detail=f"Prediction failed: {error_msg}")
        
        # Extract the report from the workflow result
        report = result.get("report", {})
        
        # Extract predictions from the report
        forecast_data = report.get("predictions", [])
        predictions = []
        
        for point in forecast_data:
            try:
                predictions.append(PricePoint(
                    date=datetime.strptime(point["date"], "%Y-%m-%d"),
                    price=point["price"],
                    confidence_lower=point.get("confidence_lower"),
                    confidence_upper=point.get("confidence_upper")
                ))
            except Exception as e:
                logger.error(f"Error parsing prediction point: {str(e)}")
                # Continue with next point
        
        # Extract feature importance from the report
        feature_importance_data = report.get("feature_importance", [])
        feature_importance = []
        
        for feature in feature_importance_data:
            feature_importance.append(FeatureImportance(
                feature=feature["feature"],
                importance=feature["importance"],
                direction=feature["direction"]
            ))
        
        # Get the current price from the market data
        current_price = report.get("current_price", 100.0)
        
        # Get the explanation from the report
        explanation = report.get("explanation", "No explanation available")
        
        # Return the prediction response
        return PredictionResponse(
            commodity=request.commodity,
            current_price=current_price,
            predictions=predictions,
            explanation=explanation if request.include_explanations else None,
            feature_importance=feature_importance if request.include_explanations else None,
            raw_data=result if request.include_raw_data else None
        )
    except Exception as e:
        logger.error(f"Error in prediction endpoint: {str(e)}")
        
        # Fallback to a simpler prediction if the agent system fails
        logger.warning("Using fallback prediction mechanism")
        
        # Generate some fallback predictions
        predictions = []
        today = datetime.now()
        
        for i in range(request.days):
            date = today + timedelta(days=i)
            price = 100.0 + (i * 0.5) + (random.random() * 2 - 1)
            confidence_lower = price - (price * 0.02)
            confidence_upper = price + (price * 0.02)
            
            predictions.append(PricePoint(
                date=date,
                price=price,
                confidence_lower=confidence_lower,
                confidence_upper=confidence_upper
            ))
        
        # Generate some fallback feature importance
        feature_importance = [
            FeatureImportance(feature="Economic Growth", importance=0.4, direction="positive"),
            FeatureImportance(feature="Interest Rates", importance=0.3, direction="negative"),
            FeatureImportance(feature="Supply Chain", importance=0.2, direction="negative"),
            FeatureImportance(feature="Market Sentiment", importance=0.1, direction="positive")
        ]
        
        return PredictionResponse(
            commodity=request.commodity,
            current_price=100.0,
            predictions=predictions,
            explanation="This is a fallback prediction as the agent system encountered an error. The model indicates a slight upward trend over the forecast period with moderate confidence.",
            feature_importance=feature_importance if request.include_explanations else None,
            raw_data={"error": str(e)} if request.include_raw_data else None
        )

@router.get("/commodities", response_model=List[str],
          summary="List available commodities",
          description="Returns a list of all commodities available for price prediction in the system.",
          response_description="List of commodity identifiers",
          status_code=200,
          responses={
              200: {
                  "description": "List of available commodities",
                  "content": {
                      "application/json": {
                          "example": ["steel", "gold", "silver", "crude_oil", "natural_gas", "copper", "aluminum"]
                      }
                  }
              }
          })
async def list_commodities():
    """
    List all available commodities for price prediction.
    
    Returns a string array of commodity identifiers that can be used in the predict endpoint.
    Commodities are grouped by categories (Metals, Energy, Construction) in the frontend.
    
    No parameters required for this endpoint.
    """
    # Get available commodities from the market data agent
    try:
        from agents.market_data import COMMODITY_TICKERS
        
        # Return the list of available commodities from the market data agent
        return list(COMMODITY_TICKERS.keys())
    except Exception as e:
        logger.error(f"Error fetching commodities: {str(e)}")
        # Fallback to a default list if there's an error
        return ["steel", "gold", "silver", "crude_oil", "natural_gas", "copper", "aluminum"]
