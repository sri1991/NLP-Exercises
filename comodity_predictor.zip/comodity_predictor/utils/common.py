"""
Common utilities for the Commodity Price Predictor.
This module contains shared functions and constants used across agents.
"""
import logging
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional, Tuple

import pandas as pd
import numpy as np

# Configure logging
logger = logging.getLogger(__name__)

# Define commodity ticker mapping
COMMODITY_TICKERS = {
    "gold": "GC=F",       # Gold futures
    "silver": "SI=F",     # Silver futures
    "crude_oil": "CL=F",  # Crude oil futures
    "natural_gas": "NG=F", # Natural gas futures
    "copper": "HG=F",     # Copper futures
    "steel": "SLX",       # Steel ETF (as a proxy)
    "aluminum": "ALI=F",  # Aluminum futures
    "platinum": "PL=F",   # Platinum futures
    "palladium": "PA=F",  # Palladium futures
    "wheat": "ZW=F",      # Wheat futures
    "corn": "ZC=F",       # Corn futures
    "soybeans": "ZS=F",   # Soybean futures
}

# Define raw material mappings for different commodities
RAW_MATERIAL_MAPPING = {
    "steel": ["iron_ore", "coal", "scrap_metal"],
    "aluminum": ["bauxite", "alumina", "electricity"],
    "copper": ["copper_ore", "electricity"],
    "gold": ["gold_ore"],
    "silver": ["silver_ore"],
    "crude_oil": ["crude_oil"],
    "natural_gas": ["natural_gas"]
}

# Define commodity-related keywords for news search
COMMODITY_KEYWORDS = {
    "steel": ["steel", "iron", "metal", "manufacturing", "construction", "infrastructure"],
    "gold": ["gold", "precious metal", "bullion", "mining"],
    "silver": ["silver", "precious metal", "bullion", "mining"],
    "crude_oil": ["crude oil", "petroleum", "oil price", "OPEC", "energy"],
    "natural_gas": ["natural gas", "LNG", "energy", "gas price"],
    "copper": ["copper", "metal", "mining", "electronics"],
    "aluminum": ["aluminum", "aluminium", "metal", "manufacturing"]
}

# Define economic indicators and their FRED series IDs
ECONOMIC_INDICATORS = {
    "gdp_growth": "GDP",          # Gross Domestic Product
    "inflation": "CPIAUCSL",      # Consumer Price Index for All Urban Consumers
    "interest_rates": "FEDFUNDS", # Federal Funds Effective Rate
    "unemployment": "UNRATE",     # Unemployment Rate
    "industrial_production": "INDPRO", # Industrial Production Index
    "pmi": "NAPM",                # ISM Manufacturing PMI
    "retail_sales": "RSXFS",      # Retail Sales
    "housing_starts": "HOUST",    # Housing Starts
}

def get_date_range(days_back: int = 365) -> Tuple[str, str]:
    """
    Get a date range from days_back until today.
    
    Args:
        days_back: Number of days to look back
        
    Returns:
        Tuple of (start_date, end_date) in YYYY-MM-DD format
    """
    end_date = datetime.now()
    start_date = end_date - timedelta(days=days_back)
    
    return start_date.strftime("%Y-%m-%d"), end_date.strftime("%Y-%m-%d")

def dataframe_to_list(df: pd.DataFrame, date_column: str = "date") -> List[Dict[str, Any]]:
    """
    Convert a pandas DataFrame to a list of dictionaries.
    
    Args:
        df: DataFrame to convert
        date_column: Name of the date column
        
    Returns:
        List of dictionaries
    """
    if df.empty:
        return []
    
    # Reset index if it's a DatetimeIndex
    if isinstance(df.index, pd.DatetimeIndex):
        df = df.reset_index()
    
    # Convert date column to string if it exists
    if date_column in df.columns and pd.api.types.is_datetime64_any_dtype(df[date_column]):
        df[date_column] = df[date_column].dt.strftime("%Y-%m-%d")
    
    # Convert to list of dictionaries
    return df.to_dict(orient="records")

def list_to_dataframe(data_list: List[Dict[str, Any]], date_column: str = "date") -> pd.DataFrame:
    """
    Convert a list of dictionaries to a pandas DataFrame.
    
    Args:
        data_list: List of dictionaries to convert
        date_column: Name of the date column
        
    Returns:
        DataFrame
    """
    if not data_list:
        return pd.DataFrame()
    
    # Convert to DataFrame
    df = pd.DataFrame(data_list)
    
    # Convert date column to datetime if it exists
    if date_column in df.columns:
        df[date_column] = pd.to_datetime(df[date_column])
        df.set_index(date_column, inplace=True)
    
    return df

def calculate_percentage_change(current: float, previous: float) -> float:
    """
    Calculate percentage change between two values.
    
    Args:
        current: Current value
        previous: Previous value
        
    Returns:
        Percentage change
    """
    if previous == 0:
        return 0
    
    return (current - previous) / previous * 100

def get_available_commodities() -> List[str]:
    """
    Get a list of available commodities for prediction.
    
    Returns:
        List of commodity names
    """
    return list(COMMODITY_TICKERS.keys())

def validate_commodity(commodity: str) -> bool:
    """
    Validate if a commodity is supported.
    
    Args:
        commodity: Commodity name to validate
        
    Returns:
        True if the commodity is supported, False otherwise
    """
    return commodity.lower() in COMMODITY_TICKERS
