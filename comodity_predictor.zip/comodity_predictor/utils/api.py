"""
API utilities for the Commodity Price Predictor.
This module provides rate limiting and retry functionality for external API calls.
"""
import logging
import time
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, Callable, TypeVar, List, Union
from functools import wraps

import requests
from requests.exceptions import RequestException

# Configure logging
logger = logging.getLogger(__name__)

# Type variable for generic function
T = TypeVar('T')

class RateLimiter:
    """Rate limiter for API calls."""
    
    def __init__(self, calls_per_second: float = 1.0, calls_per_minute: float = 60.0):
        """
        Initialize the Rate Limiter.
        
        Args:
            calls_per_second: Maximum calls per second
            calls_per_minute: Maximum calls per minute
        """
        self.calls_per_second = calls_per_second
        self.calls_per_minute = calls_per_minute
        self.last_call_time = datetime.now() - timedelta(seconds=10)  # Initialize in the past
        self.call_history: List[datetime] = []
    
    def wait_if_needed(self):
        """Wait if rate limit would be exceeded."""
        now = datetime.now()
        
        # Check calls per second
        time_since_last_call = (now - self.last_call_time).total_seconds()
        if time_since_last_call < 1.0 / self.calls_per_second:
            # Wait to respect the per-second rate limit
            sleep_time = 1.0 / self.calls_per_second - time_since_last_call
            logger.debug(f"Rate limiting: Waiting {sleep_time:.2f} seconds")
            time.sleep(sleep_time)
        
        # Update call history and remove old entries
        self.call_history = [t for t in self.call_history if (now - t).total_seconds() < 60.0]
        
        # Check calls per minute
        if len(self.call_history) >= self.calls_per_minute:
            # Wait until the oldest call is more than a minute ago
            oldest_call = self.call_history[0]
            time_since_oldest = (now - oldest_call).total_seconds()
            if time_since_oldest < 60.0:
                sleep_time = 60.0 - time_since_oldest
                logger.debug(f"Rate limiting: Waiting {sleep_time:.2f} seconds for minute limit")
                time.sleep(sleep_time)
                # Refresh now after sleeping
                now = datetime.now()
        
        # Record this call
        self.last_call_time = now
        self.call_history.append(now)

# Create rate limiters for different APIs
yfinance_limiter = RateLimiter(calls_per_second=2.0, calls_per_minute=100.0)
newsapi_limiter = RateLimiter(calls_per_second=1.0, calls_per_minute=10.0)
fred_limiter = RateLimiter(calls_per_second=1.0, calls_per_minute=20.0)
commodities_api_limiter = RateLimiter(calls_per_second=0.5, calls_per_minute=5.0)

def rate_limited(limiter: RateLimiter):
    """
    Decorator for rate-limited function calls.
    
    Args:
        limiter: Rate limiter instance
        
    Returns:
        Decorated function
    """
    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        @wraps(func)
        def wrapper(*args, **kwargs) -> T:
            # Apply rate limiting
            limiter.wait_if_needed()
            
            # Call the function
            return func(*args, **kwargs)
        
        return wrapper
    
    return decorator

def retry(max_retries: int = 3, backoff_factor: float = 1.5, 
          retry_on_exceptions: tuple = (RequestException,)):
    """
    Decorator for retrying function calls on failure.
    
    Args:
        max_retries: Maximum number of retries
        backoff_factor: Backoff factor for exponential backoff
        retry_on_exceptions: Exceptions to retry on
        
    Returns:
        Decorated function
    """
    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        @wraps(func)
        def wrapper(*args, **kwargs) -> T:
            retries = 0
            last_exception = None
            
            while retries <= max_retries:
                try:
                    return func(*args, **kwargs)
                except retry_on_exceptions as e:
                    last_exception = e
                    retries += 1
                    
                    if retries > max_retries:
                        logger.error(f"Max retries ({max_retries}) exceeded for {func.__name__}")
                        break
                    
                    # Calculate wait time with exponential backoff
                    wait_time = backoff_factor ** retries
                    logger.warning(f"Retry {retries}/{max_retries} for {func.__name__} after {wait_time:.2f}s. Error: {str(e)}")
                    time.sleep(wait_time)
            
            # If we get here, all retries failed
            if last_exception:
                raise last_exception
            
            # This should never happen, but just in case
            raise Exception(f"All retries failed for {func.__name__}")
        
        return wrapper
    
    return decorator

def safe_request(url: str, method: str = "GET", params: Optional[Dict[str, Any]] = None, 
                headers: Optional[Dict[str, Any]] = None, data: Optional[Union[Dict[str, Any], str]] = None, 
                timeout: int = 10, verify: bool = True) -> requests.Response:
    """
    Make a safe HTTP request with retries and error handling.
    
    Args:
        url: URL to request
        method: HTTP method (GET, POST, etc.)
        params: Query parameters
        headers: HTTP headers
        data: Request body data
        timeout: Request timeout in seconds
        verify: Whether to verify SSL certificates
        
    Returns:
        Response object
        
    Raises:
        RequestException: If the request fails after retries
    """
    @retry(max_retries=3, backoff_factor=1.5)
    def _make_request():
        response = requests.request(
            method=method,
            url=url,
            params=params,
            headers=headers,
            data=data,
            timeout=timeout,
            verify=verify
        )
        
        # Raise an exception for 4xx/5xx status codes
        response.raise_for_status()
        
        return response
    
    return _make_request()

def get_api_key(key_name: str) -> Optional[str]:
    """
    Get an API key from environment variables.
    
    Args:
        key_name: Name of the API key environment variable
        
    Returns:
        API key or None if not found
    """
    import os
    
    api_key = os.environ.get(key_name)
    
    if not api_key:
        logger.warning(f"API key {key_name} not found in environment variables")
        return None
    
    return api_key
