"""
Caching utilities for the Commodity Price Predictor.
This module provides Redis-based caching functionality for API responses.
"""
import logging
import json
import os
from datetime import datetime, timedelta
from typing import Dict, Any, Optional, Callable, TypeVar, cast

import redis
from functools import wraps

# Configure logging
logger = logging.getLogger(__name__)

# Type variable for generic function
T = TypeVar('T')

class CacheManager:
    """Redis-based cache manager for API responses."""
    
    def __init__(self):
        """Initialize the Cache Manager."""
        self.redis_client = None
        self._initialize_redis()
    
    def _initialize_redis(self):
        """Initialize Redis connection if configured."""
        try:
            redis_host = os.environ.get("REDIS_HOST")
            redis_port = os.environ.get("REDIS_PORT")
            redis_password = os.environ.get("REDIS_PASSWORD")
            
            if redis_host and redis_port:
                logger.info(f"Initializing Redis connection to {redis_host}:{redis_port}")
                
                # Create Redis client
                self.redis_client = redis.Redis(
                    host=redis_host,
                    port=int(redis_port),
                    password=redis_password,
                    decode_responses=False,  # Keep as bytes for proper serialization
                    socket_timeout=5,
                    socket_connect_timeout=5
                )
                
                # Test connection
                self.redis_client.ping()
                logger.info("Redis connection successful")
            else:
                logger.warning("Redis not configured. Caching disabled.")
        except Exception as e:
            logger.error(f"Failed to initialize Redis: {str(e)}")
            self.redis_client = None
    
    def get(self, key: str) -> Optional[Dict[str, Any]]:
        """
        Get a value from the cache.
        
        Args:
            key: Cache key
            
        Returns:
            Cached value or None if not found
        """
        if not self.redis_client:
            return None
        
        try:
            # Get value from Redis
            value = self.redis_client.get(key)
            
            if value:
                # Deserialize JSON
                return json.loads(value)
            
            return None
        except Exception as e:
            logger.error(f"Error getting value from cache: {str(e)}")
            return None
    
    def set(self, key: str, value: Dict[str, Any], ttl_seconds: int = 3600) -> bool:
        """
        Set a value in the cache.
        
        Args:
            key: Cache key
            value: Value to cache
            ttl_seconds: Time to live in seconds
            
        Returns:
            True if successful, False otherwise
        """
        if not self.redis_client:
            return False
        
        try:
            # Serialize to JSON
            serialized = json.dumps(value)
            
            # Set value in Redis with TTL
            self.redis_client.setex(key, ttl_seconds, serialized)
            
            return True
        except Exception as e:
            logger.error(f"Error setting value in cache: {str(e)}")
            return False
    
    def delete(self, key: str) -> bool:
        """
        Delete a value from the cache.
        
        Args:
            key: Cache key
            
        Returns:
            True if successful, False otherwise
        """
        if not self.redis_client:
            return False
        
        try:
            # Delete key from Redis
            self.redis_client.delete(key)
            
            return True
        except Exception as e:
            logger.error(f"Error deleting value from cache: {str(e)}")
            return False
    
    def clear_all(self) -> bool:
        """
        Clear all cached values.
        
        Returns:
            True if successful, False otherwise
        """
        if not self.redis_client:
            return False
        
        try:
            # Flush all keys
            self.redis_client.flushall()
            
            return True
        except Exception as e:
            logger.error(f"Error clearing cache: {str(e)}")
            return False

# Create a singleton instance
cache_manager = CacheManager()

def cached(ttl_seconds: int = 3600):
    """
    Decorator for caching function results.
    
    Args:
        ttl_seconds: Time to live in seconds
        
    Returns:
        Decorated function
    """
    def decorator(func: Callable[..., T]) -> Callable[..., T]:
        @wraps(func)
        def wrapper(*args, **kwargs) -> T:
            # Generate cache key
            key_parts = [func.__name__]
            
            # Add args to key
            for arg in args:
                if isinstance(arg, (str, int, float, bool)):
                    key_parts.append(str(arg))
            
            # Add kwargs to key
            for k, v in sorted(kwargs.items()):
                if isinstance(v, (str, int, float, bool)):
                    key_parts.append(f"{k}:{v}")
            
            # Create cache key
            cache_key = ":".join(key_parts)
            
            # Try to get from cache
            cached_result = cache_manager.get(cache_key)
            
            if cached_result is not None:
                logger.debug(f"Cache hit for {cache_key}")
                return cast(T, cached_result)
            
            # Call the function
            result = func(*args, **kwargs)
            
            # Cache the result
            if isinstance(result, dict):
                cache_manager.set(cache_key, result, ttl_seconds)
            
            return result
        
        return wrapper
    
    return decorator

def get_cache_manager() -> CacheManager:
    """
    Get the cache manager instance.
    
    Returns:
        Cache manager instance
    """
    return cache_manager
