"""
Test script for the raw material agent.
"""
import logging
from datetime import datetime, timedelta
from agents.raw_material import fetch_raw_material_data

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)

def main():
    """Test the raw material agent."""
    # Define test parameters
    today = datetime.now()
    start_date = (today - timedelta(days=90)).strftime("%Y-%m-%d")  # Last 90 days
    end_date = today.strftime("%Y-%m-%d")
    
    date_range = {
        "start": start_date,
        "end": end_date
    }
    
    # Test with a few different commodities
    commodities = ["steel", "gold", "copper", "crude_oil"]
    
    for commodity in commodities:
        logger.info(f"Testing raw material agent for {commodity} from {start_date} to {end_date}")
        
        try:
            # Call the raw material agent
            result = fetch_raw_material_data(commodity, date_range)
            
            # Print the result metadata
            logger.info(f"Raw material agent returned data with source: {result['metadata']['source']}")
            logger.info(f"Raw materials for {commodity}: {result['metadata'].get('raw_materials', [])}")
            
            # Check each raw material
            for material, data in result.items():
                if material != "metadata":
                    data_points = len(data)
                    logger.info(f"Raw material '{material}': {data_points} data points")
                    if data_points > 0:
                        logger.info(f"  First data point: {data[0]}")
                        logger.info(f"  Last data point: {data[-1]}")
        
        except Exception as e:
            logger.error(f"Error testing raw material agent for {commodity}: {str(e)}")
    
    return "Testing complete"

if __name__ == "__main__":
    main()
