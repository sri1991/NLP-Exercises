# Commodity Price Predictor

A microservices-based agentic system for commodity price prediction using LangGraph.

## Architecture

This system uses a multi-agent architecture where each agent is responsible for a specific task:

- **Market Data Agent**: Fetches historical and current commodity prices
- **Macro Data Agent**: Retrieves macroeconomic indicators
- **Raw Material Agent**: Collects prices of raw materials
- **News Agent**: Scrapes news and performs sentiment analysis
- **Feature Engineering Agent**: Prepares data for modeling
- **Prediction Agent**: Generates price forecasts
- **Explainability Agent**: Provides insights into predictions
- **Reporting Agent**: Formats results for presentation

## Setup

1. Install dependencies:
```
pip install -r requirements.txt
```

2. Set up environment variables:
```
cp .env.example .env
```
Then edit the `.env` file with your API keys.

3. Run the application:
```
python main.py
```

## API Documentation

The system exposes a RESTful API using FastAPI. Once running, access the API documentation at:
```
http://localhost:8000/docs
```
