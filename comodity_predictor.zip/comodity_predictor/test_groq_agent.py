"""
Test script for a simple agent using Groq LLM.
This script tests a basic agent workflow without requiring the full orchestrator.
"""
import logging
import os
from datetime import datetime, timedelta
from dotenv import load_dotenv
from langchain_groq import ChatGroq
from langchain.prompts import ChatPromptTemplate
from langchain_core.output_parsers import JsonOutputParser
from agents.market_data import fetch_market_data

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)

def main():
    """Test a simple agent workflow using Groq."""
    # Check if GROQ_API_KEY is set
    groq_api_key = os.getenv("GROQ_API_KEY")
    if not groq_api_key:
        logger.warning("GROQ_API_KEY not set. Using dummy mode.")
        test_market_data_only()
        return
    
    # Initialize Groq LLM
    try:
        llm = ChatGroq(
            model_name="llama3-8b-8192",  # Using Llama 3 8B model
            temperature=0.2,
        )
        logger.info("Groq LLM initialized successfully")
        
        # Test market data agent
        commodity = "gold"
        today = datetime.now()
        start_date = (today - timedelta(days=30)).strftime("%Y-%m-%d")
        end_date = today.strftime("%Y-%m-%d")
        
        date_range = {
            "start": start_date,
            "end": end_date
        }
        
        logger.info(f"Fetching market data for {commodity}")
        market_data = fetch_market_data(commodity, date_range)
        
        # Create a simple prompt for the LLM
        prompt = ChatPromptTemplate.from_messages([
            ("system", "You are a commodity price analysis assistant. Analyze the provided market data and provide insights."),
            ("human", "Please analyze this market data for {commodity} and provide a brief summary of the price trends:\n{market_data}")
        ])
        
        # Create the chain
        chain = prompt | llm
        
        # Run the chain
        logger.info("Running Groq LLM to analyze market data")
        response = chain.invoke({
            "commodity": commodity,
            "market_data": str(market_data)
        })
        
        logger.info("Groq LLM response:")
        logger.info(response.content)
        
        return response.content
    
    except Exception as e:
        logger.error(f"Error testing Groq agent: {str(e)}")
        logger.info("Falling back to market data agent only")
        test_market_data_only()

def test_market_data_only():
    """Test just the market data agent without LLM."""
    commodity = "gold"
    today = datetime.now()
    start_date = (today - timedelta(days=30)).strftime("%Y-%m-%d")
    end_date = today.strftime("%Y-%m-%d")
    
    date_range = {
        "start": start_date,
        "end": end_date
    }
    
    logger.info(f"Testing market data agent for {commodity} from {start_date} to {end_date}")
    
    try:
        # Call the market data agent
        result = fetch_market_data(commodity, date_range)
        
        # Print the result
        logger.info(f"Market data agent returned {len(result['prices'])} data points")
        logger.info(f"First data point: {result['prices'][0] if result['prices'] else 'No data'}")
        logger.info(f"Last data point: {result['prices'][-1] if result['prices'] else 'No data'}")
        logger.info(f"Metadata: {result['metadata']}")
        
        return result
    except Exception as e:
        logger.error(f"Error testing market data agent: {str(e)}")
        raise

if __name__ == "__main__":
    main()
