"""
Main entry point for the Commodity Price Predictor application.
This module initializes the agentic system and starts the API server.
"""
import os
import logging
from dotenv import load_dotenv
import uvicorn
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware
from api.router import router as api_router
from orchestrator.graph import create_agent_graph

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=getattr(logging, os.getenv("LOG_LEVEL", "INFO")),
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)

# Initialize FastAPI app
app = FastAPI(
    title="Commodity Price Predictor",
    description="An agentic system for predicting commodity prices",
    version="0.1.0",
)

# Configure CORS middleware
app.add_middleware(
    CORSMiddleware,
    allow_origins=["http://localhost:8081", "http://localhost:3000"],  # Frontend URLs
    allow_credentials=True,
    allow_methods=["*"],  # Allow all methods
    allow_headers=["*"],  # Allow all headers
)

# Include API routes
app.include_router(api_router, prefix="/api")

# Initialize agent graph
agent_graph = create_agent_graph()

@app.on_event("startup")
async def startup_event():
    """Initialize components on startup."""
    logger.info("Starting Commodity Price Predictor")
    # Any additional initialization can go here

if __name__ == "__main__":
    # Start the API server
    host = os.getenv("API_HOST", "0.0.0.0")
    port = int(os.getenv("API_PORT", "8000"))
    logger.info(f"Starting API server on {host}:{port}")
    uvicorn.run("main:app", host=host, port=port, reload=os.getenv("DEBUG", "False").lower() == "true")
