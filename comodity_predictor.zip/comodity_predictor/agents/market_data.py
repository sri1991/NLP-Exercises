"""
Market Data Agent for the Commodity Price Predictor.
This module is responsible for fetching historical and current commodity prices.
"""
import logging
import os
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional

import pandas as pd
import yfinance as yf
import requests
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Configure logging
logger = logging.getLogger(__name__)

# Define commodity ticker mapping
COMMODITY_TICKERS = {
    "gold": "GC=F",       # Gold futures
    "silver": "SI=F",     # Silver futures
    "crude_oil": "CL=F",  # Crude oil futures
    "natural_gas": "NG=F", # Natural gas futures
    "copper": "HG=F",     # Copper futures
    "steel": "SLX",       # Steel ETF (as a proxy)
    "aluminum": "ALI=F",  # Aluminum futures
    "platinum": "PL=F",   # Platinum futures
    "palladium": "PA=F",  # Palladium futures
    "wheat": "ZW=F",      # Wheat futures
    "corn": "ZC=F",       # Corn futures
    "soybeans": "ZS=F",   # Soybean futures
}

class MarketDataAgent:
    """Agent for fetching commodity market data."""
    
    def __init__(self):
        """Initialize the Market Data Agent."""
        self.commodities_api_key = os.getenv("COMMODITIES_API_KEY")
        logger.info("Market Data Agent initialized")
    
    def fetch_data(self, commodity: str, start_date: str, end_date: str) -> Dict[str, Any]:
        """
        Fetch historical and current price data for a commodity.
        
        Args:
            commodity: The commodity to fetch data for
            start_date: Start date in YYYY-MM-DD format
            end_date: End date in YYYY-MM-DD format
            
        Returns:
            Dictionary containing price data and metadata
        """
        logger.info(f"Fetching market data for {commodity} from {start_date} to {end_date}")
        
        try:
            # Try to fetch data using yfinance first
            data = self._fetch_from_yfinance(commodity, start_date, end_date)
            source = "yfinance"
            
            # If yfinance data is empty or None, try alternative sources
            if data is None or len(data) == 0:
                logger.warning(f"No data found for {commodity} in yfinance, trying alternative sources")
                data = self._fetch_from_alternative_sources(commodity, start_date, end_date)
                if data and len(data) > 0:
                    source = "alternative"
                else:
                    logger.error(f"No data available for {commodity} from any source")
                    raise ValueError(f"No market data available for {commodity}")
            
            # Format the response
            return {
                "prices": data,
                "metadata": {
                    "commodity": commodity,
                    "start_date": start_date,
                    "end_date": end_date,
                    "source": source,
                    "last_updated": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                }
            }
        except Exception as e:
            logger.error(f"Error fetching market data: {str(e)}")
            raise
    
    def _fetch_from_yfinance(self, commodity: str, start_date: str, end_date: str) -> List[Dict[str, Any]]:
        """
        Fetch commodity data from Yahoo Finance.
        
        Args:
            commodity: The commodity to fetch data for
            start_date: Start date in YYYY-MM-DD format
            end_date: End date in YYYY-MM-DD format
            
        Returns:
            List of price data points
        """
        # Get the ticker for the commodity
        ticker = COMMODITY_TICKERS.get(commodity.lower())
        if not ticker:
            logger.warning(f"No ticker found for commodity: {commodity}")
            return []
        
        # Fetch data from yfinance
        try:
            data = yf.download(ticker, start=start_date, end=end_date)
            
            # Convert to list of dictionaries
            result = []
            for date, row in data.iterrows():
                result.append({
                    "date": date.strftime("%Y-%m-%d"),
                    "price": float(row["Close"].iloc[0]) if hasattr(row["Close"], "iloc") else float(row["Close"]),
                    "open": float(row["Open"].iloc[0]) if hasattr(row["Open"], "iloc") else float(row["Open"]),
                    "high": float(row["High"].iloc[0]) if hasattr(row["High"], "iloc") else float(row["High"]),
                    "low": float(row["Low"].iloc[0]) if hasattr(row["Low"], "iloc") else float(row["Low"]),
                    "volume": float(row["Volume"].iloc[0]) if hasattr(row["Volume"], "iloc") else float(row["Volume"])
                })
            
            return result
        except Exception as e:
            logger.error(f"Error fetching data from yfinance: {str(e)}")
            return []
    
    def _fetch_from_alternative_sources(self, commodity: str, start_date: str, end_date: str) -> List[Dict[str, Any]]:
        """
        Fetch commodity data from alternative sources when yfinance fails.
        
        Args:
            commodity: The commodity to fetch data for
            start_date: Start date in YYYY-MM-DD format
            end_date: End date in YYYY-MM-DD format
            
        Returns:
            List of price data points
        """
        # Try to fetch from Commodities-API if we have an API key
        if self.commodities_api_key:
            data = self._fetch_from_commodities_api(commodity, start_date, end_date)
            if data and len(data) > 0:
                return data
        
        # No alternative data sources available
        logger.warning(f"No alternative data sources available for {commodity}")
        return []
    
    def _fetch_from_commodities_api(self, commodity: str, start_date: str, end_date: str) -> List[Dict[str, Any]]:
        """
        Fetch commodity data from Commodities-API.
        
        Args:
            commodity: The commodity to fetch data for
            start_date: Start date in YYYY-MM-DD format
            end_date: End date in YYYY-MM-DD format
            
        Returns:
            List of price data points
        """
        # Map commodity to symbol used by Commodities-API
        commodity_map = {
            "gold": "XAU",
            "silver": "XAG",
            "crude_oil": "BRENT",
            "natural_gas": "NG",
            "copper": "COPPER",
            "steel": "STEEL",
            "aluminum": "ALU"
        }
        
        symbol = commodity_map.get(commodity.lower(), commodity.upper())
        
        # Construct API URL
        base_url = "https://commodities-api.com/api/timeseries"
        params = {
            "access_key": self.commodities_api_key,
            "start_date": start_date,
            "end_date": end_date,
            "base": "USD",
            "symbols": symbol
        }
        
        # Make API request
        response = requests.get(base_url, params=params)
        data = response.json()
        
        if data.get("success"):
            rates = data.get("rates", {})
            result = []
            
            for date, rate_data in rates.items():
                price = 1 / rate_data.get(symbol, 1)  # Convert rate to price
                result.append({
                    "date": date,
                    "price": price
                })
            
            return result
        else:
            logger.error(f"Commodities-API error: {data.get('error', {}).get('info')}")
            return []
    


# Create a singleton instance
market_data_agent = MarketDataAgent()

def fetch_market_data(commodity: str, date_range: Dict[str, str]) -> Dict[str, Any]:
    """
    Fetch market data for a commodity.
    
    Args:
        commodity: The commodity to fetch data for
        date_range: Dictionary with 'start' and 'end' dates
        
    Returns:
        Dictionary containing price data and metadata
    """
    return market_data_agent.fetch_data(
        commodity=commodity,
        start_date=date_range["start"],
        end_date=date_range["end"]
    )
