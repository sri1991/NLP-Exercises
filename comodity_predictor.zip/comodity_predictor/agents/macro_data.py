"""
Macro Data Agent for the Commodity Price Predictor.
This module is responsible for retrieving macroeconomic indicators.
"""
import logging
import os
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional

import pandas as pd
import requests
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Configure logging
logger = logging.getLogger(__name__)

# Define economic indicators and their FRED series IDs
ECONOMIC_INDICATORS = {
    "gdp_growth": "GDP",          # Gross Domestic Product
    "inflation": "CPIAUCSL",      # Consumer Price Index for All Urban Consumers
    "interest_rates": "FEDFUNDS", # Federal Funds Effective Rate
    "unemployment": "UNRATE",     # Unemployment Rate
    "industrial_production": "INDPRO", # Industrial Production Index
    "pmi": "NAPM",                # ISM Manufacturing PMI
    "retail_sales": "RSXFS",      # Retail Sales
    "housing_starts": "HOUST",    # Housing Starts
}

class MacroDataAgent:
    """Agent for fetching macroeconomic data."""
    
    def __init__(self):
        """Initialize the Macro Data Agent."""
        self.fred_api_key = os.getenv("FRED_API_KEY")
        logger.info("Macro Data Agent initialized")
    
    def fetch_data(self, start_date: str, end_date: str, region: str = "US") -> Dict[str, Any]:
        """
        Fetch macroeconomic indicators.
        
        Args:
            start_date: Start date in YYYY-MM-DD format
            end_date: End date in YYYY-MM-DD format
            region: Region to fetch data for (default: US)
            
        Returns:
            Dictionary containing economic indicators and metadata
        """
        logger.info(f"Fetching macroeconomic data from {start_date} to {end_date} for region {region}")
        
        try:
            # Check if we have a FRED API key
            if self.fred_api_key:
                data = self._fetch_from_fred(start_date, end_date)
                source = "FRED"
            else:
                # No API key available
                logger.error("No FRED API key found. Cannot fetch macroeconomic data.")
                raise ValueError("FRED_API_KEY is required to fetch macroeconomic data")
            
            # Format the response
            return {
                **data,
                "metadata": {
                    "start_date": start_date,
                    "end_date": end_date,
                    "region": region,
                    "source": source,
                    "last_updated": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                }
            }
        except Exception as e:
            logger.error(f"Error fetching macroeconomic data: {str(e)}")
            raise
    
    def _fetch_from_fred(self, start_date: str, end_date: str) -> Dict[str, List[Dict[str, Any]]]:
        """
        Fetch economic indicators from FRED API.
        
        Args:
            start_date: Start date in YYYY-MM-DD format
            end_date: End date in YYYY-MM-DD format
            
        Returns:
            Dictionary with economic indicators
        """
        result = {}
        
        # Convert dates to FRED format (YYYY-MM-DD)
        start = start_date
        end = end_date
        
        # Base URL for FRED API
        base_url = "https://api.stlouisfed.org/fred/series/observations"
        
        # Fetch each indicator
        for indicator_name, series_id in ECONOMIC_INDICATORS.items():
            try:
                # Construct API URL
                params = {
                    "series_id": series_id,
                    "api_key": self.fred_api_key,
                    "file_type": "json",
                    "observation_start": start,
                    "observation_end": end,
                    "frequency": "m",  # Monthly frequency
                    "sort_order": "asc"
                }
                
                # Make API request
                response = requests.get(base_url, params=params)
                data = response.json()
                
                # Extract observations
                observations = data.get("observations", [])
                indicator_data = []
                
                for obs in observations:
                    # Skip missing values
                    if obs.get("value") == ".":
                        continue
                    
                    indicator_data.append({
                        "date": obs.get("date"),
                        "value": float(obs.get("value"))
                    })
                
                result[indicator_name] = indicator_data
                
            except Exception as e:
                logger.error(f"Error fetching {indicator_name} from FRED: {str(e)}")
                # If there's an error, add an empty list for this indicator
                result[indicator_name] = []
        
        return result
    


# Create a singleton instance
macro_data_agent = MacroDataAgent()

def fetch_macro_data(date_range: Dict[str, str], region: str = "US") -> Dict[str, Any]:
    """
    Fetch macroeconomic data.
    
    Args:
        date_range: Dictionary with 'start' and 'end' dates
        region: Region to fetch data for (default: US)
        
    Returns:
        Dictionary containing economic indicators and metadata
    """
    return macro_data_agent.fetch_data(
        start_date=date_range["start"],
        end_date=date_range["end"],
        region=region
    )
