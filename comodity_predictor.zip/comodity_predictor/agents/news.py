"""
News Agent for the Commodity Price Predictor.
This module is responsible for scraping news and performing sentiment analysis.
"""
import logging
import os
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional
import json

import requests
from newsapi import NewsApiClient
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Configure logging
logger = logging.getLogger(__name__)

# Define commodity-related keywords
COMMODITY_KEYWORDS = {
    "steel": ["steel", "iron", "metal", "manufacturing", "construction", "infrastructure"],
    "gold": ["gold", "precious metal", "bullion", "mining"],
    "silver": ["silver", "precious metal", "bullion", "mining"],
    "crude_oil": ["crude oil", "petroleum", "oil price", "OPEC", "energy"],
    "natural_gas": ["natural gas", "LNG", "energy", "gas price"],
    "copper": ["copper", "metal", "mining", "electronics"],
    "aluminum": ["aluminum", "aluminium", "metal", "manufacturing"]
}

class NewsAgent:
    """Agent for fetching and analyzing news related to commodities."""
    
    def __init__(self):
        """Initialize the News Agent."""
        self.newsapi_key = os.getenv("NEWSAPI_KEY")
        if self.newsapi_key:
            self.newsapi = NewsApiClient(api_key=self.newsapi_key)
        else:
            self.newsapi = None
            logger.warning("No NewsAPI key found. A key is required to fetch news data.")
        
        logger.info("News Agent initialized")
    
    def fetch_data(self, commodity: str, days_back: int = 30) -> Dict[str, Any]:
        """
        Fetch and analyze news related to a commodity.
        
        Args:
            commodity: The commodity to fetch news for
            days_back: Number of days to look back for news
            
        Returns:
            Dictionary containing news articles, sentiment analysis, and metadata
        """
        logger.info(f"Fetching news data for {commodity} from the past {days_back} days")
        
        try:
            # Calculate the date range
            end_date = datetime.now()
            start_date = end_date - timedelta(days=days_back)
            
            # Format dates for NewsAPI
            from_date = start_date.strftime("%Y-%m-%d")
            to_date = end_date.strftime("%Y-%m-%d")
            
            # Get relevant keywords for this commodity
            keywords = COMMODITY_KEYWORDS.get(commodity.lower(), [commodity])
            
            # Fetch news articles
            if self.newsapi:
                articles = self._fetch_from_newsapi(commodity, keywords, from_date, to_date)
                source = "NewsAPI"
            else:
                logger.error(f"No NewsAPI key found. Cannot fetch news data for {commodity}.")
                raise ValueError("NEWSAPI_KEY is required to fetch news data")
            
            # Perform sentiment analysis
            analyzed_articles = self._analyze_sentiment(articles)
            
            # Calculate overall sentiment
            overall_sentiment = self._calculate_overall_sentiment(analyzed_articles)
            
            # Format the response
            return {
                "articles": analyzed_articles,
                "overall_sentiment": overall_sentiment,
                "metadata": {
                    "commodity": commodity,
                    "keywords": keywords,
                    "from_date": from_date,
                    "to_date": to_date,
                    "source": source,
                    "last_updated": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                }
            }
        except Exception as e:
            logger.error(f"Error fetching news data: {str(e)}")
            raise
    
    def _fetch_from_newsapi(self, commodity: str, keywords: List[str], from_date: str, to_date: str) -> List[Dict[str, Any]]:
        """
        Fetch news articles from NewsAPI.
        
        Args:
            commodity: The commodity to fetch news for
            keywords: List of keywords to search for
            from_date: Start date in YYYY-MM-DD format
            to_date: End date in YYYY-MM-DD format
            
        Returns:
            List of news articles
        """
        articles = []
        
        try:
            logger.info(f"Fetching news for commodity: {commodity}, keywords: {keywords}")
            
            # Create a query string from keywords
            # Filter out None values and ensure we have valid keywords
            valid_keywords = [k for k in keywords if k]
            
            if valid_keywords:
                query = f"{commodity} OR {' OR '.join(valid_keywords)}"
            else:
                query = commodity
                
            logger.info(f"NewsAPI query: {query}")
            
            # Make API request
            response = self.newsapi.get_everything(
                q=query,
                from_param=from_date,
                to=to_date,
                language='en',
                sort_by='relevancy',
                page_size=100
            )
            
            # Extract articles
            raw_articles = response.get("articles", [])
            logger.info(f"NewsAPI returned {len(raw_articles)} articles")
            
            # Process articles
            for article in raw_articles:
                # Debug article structure
                if article is None:
                    logger.warning("Received None article from NewsAPI")
                    continue
                    
                title = article.get("title", "")
                published_at = article.get("publishedAt", "")
                date = published_at[:10] if published_at else ""
                source_obj = article.get("source", {})
                source_name = source_obj.get("name", "Unknown") if source_obj else "Unknown"
                url = article.get("url", "")
                description = article.get("description", "")
                
                articles.append({
                    "title": title,
                    "date": date,
                    "source": source_name,
                    "url": url,
                    "description": description
                })
            
            return articles
        except Exception as e:
            logger.error(f"Error fetching from NewsAPI: {str(e)}")
            return []
    
    def _analyze_sentiment(self, articles: List[Dict[str, Any]]) -> List[Dict[str, Any]]:
        """
        Perform sentiment analysis on news articles.
        
        In a production system, this would use a proper NLP model or API.
        For this implementation, we'll use a simple rule-based approach.
        
        Args:
            articles: List of news articles
            
        Returns:
            List of articles with sentiment scores
        """
        try:
            logger.info(f"Analyzing sentiment for {len(articles)} articles")
            
            # Define positive and negative keywords
            positive_words = [
                "increase", "rise", "gain", "growth", "positive", "up", "higher",
                "strong", "strengthen", "bullish", "optimistic", "recovery", "boom"
            ]
            
            negative_words = [
                "decrease", "fall", "drop", "decline", "negative", "down", "lower",
                "weak", "weaken", "bearish", "pessimistic", "recession", "bust", "crisis"
            ]
            
            analyzed_articles = []
            
            for i, article in enumerate(articles):
                try:
                    # Debug article structure
                    logger.debug(f"Processing article {i+1}/{len(articles)}")
                    
                    # Get title and description safely
                    title = article.get("title", "") if article else ""
                    description = article.get("description", "") if article else ""
                    
                    # Combine title and description for analysis
                    text = (title + " " + description).lower()
                    
                    # Count positive and negative words
                    pos_count = sum(1 for word in positive_words if word in text)
                    neg_count = sum(1 for word in negative_words if word in text)
                    
                    # Calculate sentiment score (-1 to 1)
                    total = pos_count + neg_count
                    if total > 0:
                        sentiment = (pos_count - neg_count) / total
                    else:
                        sentiment = 0.0
                    
                    # Generate a summary (in a real system, this would use an LLM or summarization model)
                    summary = description
                    if not summary:
                        summary = title if title else "No summary available"
                    
                    # Add sentiment and summary to the article
                    analyzed_article = {}
                    if article:
                        analyzed_article = {**article}
                    analyzed_article["sentiment"] = round(sentiment, 2)
                    analyzed_article["summary"] = summary
                    
                    analyzed_articles.append(analyzed_article)
                except Exception as e:
                    logger.error(f"Error analyzing article {i}: {str(e)}")
                    # Add a placeholder with error information
                    analyzed_articles.append({
                        "title": "Error analyzing article",
                        "date": "",
                        "source": "Error",
                        "url": "",
                        "description": str(e),
                        "sentiment": 0.0,
                        "summary": "Error during analysis"
                    })
            
            return analyzed_articles
        except Exception as e:
            logger.error(f"Error in sentiment analysis: {str(e)}")
            return []
    
    def _calculate_overall_sentiment(self, articles: List[Dict[str, Any]]) -> float:
        """
        Calculate overall sentiment from all articles.
        
        Args:
            articles: List of articles with sentiment scores
            
        Returns:
            Overall sentiment score (-1 to 1)
        """
        if not articles:
            return 0.0
        
        # Calculate weighted average of sentiment scores
        # More recent articles get higher weight
        total_weight = 0
        weighted_sum = 0
        
        for i, article in enumerate(articles):
            # Weight decreases with age (assuming articles are sorted by date)
            weight = len(articles) - i
            sentiment = article.get("sentiment", 0)
            
            weighted_sum += sentiment * weight
            total_weight += weight
        
        if total_weight > 0:
            return round(weighted_sum / total_weight, 2)
        else:
            return 0.0


# Create a singleton instance
news_agent = NewsAgent()

def fetch_news_data(commodity: str, days_back: int = 30) -> Dict[str, Any]:
    """
    Fetch news data for a commodity.
    
    Args:
        commodity: The commodity to fetch news for
        days_back: Number of days to look back for news
        
    Returns:
        Dictionary containing news articles, sentiment analysis, and metadata
    """
    return news_agent.fetch_data(
        commodity=commodity,
        days_back=days_back
    )
