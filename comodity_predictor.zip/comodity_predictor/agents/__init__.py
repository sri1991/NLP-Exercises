"""
Agents package for the Commodity Price Predictor.
This package contains the implementation of all specialized agents.
"""
