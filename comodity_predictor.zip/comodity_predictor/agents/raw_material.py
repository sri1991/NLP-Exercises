"""
Raw Material Agent for the Commodity Price Predictor.
This module is responsible for collecting prices of raw materials.
"""
import logging
import os
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional

import pandas as pd
import yfinance as yf
import requests
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Configure logging
logger = logging.getLogger(__name__)

# Define raw material mappings for different commodities
RAW_MATERIAL_MAPPING = {
    "steel": ["iron_ore", "coal", "scrap_metal"],
    "aluminum": ["bauxite", "alumina", "electricity"],
    "copper": ["copper_ore", "electricity"],
    "gold": ["gold_ore"],
    "silver": ["silver_ore"],
    "crude_oil": ["crude_oil"],
    "natural_gas": ["natural_gas"]
}

# Define ticker symbols for raw materials
RAW_MATERIAL_TICKERS = {
    "iron_ore": "TIOC=F",  # Iron Ore futures
    "coal": "MTF=F",       # Coal futures
    "scrap_metal": None,   # No direct ticker
    "bauxite": None,       # No direct ticker
    "alumina": None,       # No direct ticker
    "copper_ore": "HG=F",  # Copper futures as proxy
    "gold_ore": "GC=F",    # Gold futures as proxy
    "silver_ore": "SI=F",  # Silver futures as proxy
    "crude_oil": "CL=F",   # Crude oil futures
    "natural_gas": "NG=F"  # Natural gas futures
}

class RawMaterialAgent:
    """Agent for fetching raw material price data."""
    
    def __init__(self):
        """Initialize the Raw Material Agent."""
        self.commodities_api_key = os.getenv("COMMODITIES_API_KEY")
        logger.info("Raw Material Agent initialized")
    
    def fetch_data(self, commodity: str, start_date: str, end_date: str) -> Dict[str, Any]:
        """
        Fetch raw material prices related to a commodity.
        
        Args:
            commodity: The commodity to fetch raw material data for
            start_date: Start date in YYYY-MM-DD format
            end_date: End date in YYYY-MM-DD format
            
        Returns:
            Dictionary containing raw material price data and metadata
        """
        logger.info(f"Fetching raw material data for {commodity} from {start_date} to {end_date}")
        
        try:
            # Get the list of raw materials for this commodity
            raw_materials = RAW_MATERIAL_MAPPING.get(commodity.lower(), [])
            
            if not raw_materials:
                logger.warning(f"No raw materials defined for commodity: {commodity}")
                return {
                    "metadata": {
                        "commodity": commodity,
                        "start_date": start_date,
                        "end_date": end_date,
                        "source": "none",
                        "last_updated": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                    }
                }
            
            # Fetch data for each raw material
            result = {}
            for material in raw_materials:
                # Try to fetch from yfinance first
                data = self._fetch_from_yfinance(material, start_date, end_date)
                source = "yfinance"
                
                # If no data from yfinance, try alternative sources
                if not data:
                    logger.warning(f"No yfinance data for {material}, trying alternative sources")
                    if self.commodities_api_key:
                        data = self._fetch_from_commodities_api(material, start_date, end_date)
                        if data:
                            source = "commodities-api"
                        else:
                            logger.error(f"No data available for raw material: {material}")
                            data = []
                    else:
                        logger.error(f"No alternative data sources available for raw material: {material}")
                        data = []
                
                result[material] = data
            
            # Format the response
            return {
                **result,
                "metadata": {
                    "commodity": commodity,
                    "raw_materials": raw_materials,
                    "start_date": start_date,
                    "end_date": end_date,
                    "source": source,
                    "last_updated": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                }
            }
        except Exception as e:
            logger.error(f"Error fetching raw material data: {str(e)}")
            raise
    
    def _fetch_from_yfinance(self, material: str, start_date: str, end_date: str) -> List[Dict[str, Any]]:
        """
        Fetch raw material data from Yahoo Finance.
        
        Args:
            material: The raw material to fetch data for
            start_date: Start date in YYYY-MM-DD format
            end_date: End date in YYYY-MM-DD format
            
        Returns:
            List of price data points
        """
        # Get the ticker for the raw material
        ticker = RAW_MATERIAL_TICKERS.get(material.lower())
        if not ticker:
            logger.warning(f"No ticker found for raw material: {material}")
            return []
        
        # Fetch data from yfinance
        try:
            data = yf.download(ticker, start=start_date, end=end_date)
            
            # Convert to list of dictionaries
            result = []
            for date, row in data.iterrows():
                result.append({
                    "date": date.strftime("%Y-%m-%d"),
                    "price": float(row["Close"].iloc[0]) if hasattr(row["Close"], "iloc") else float(row["Close"])
                })
            
            return result
        except Exception as e:
            logger.error(f"Error fetching data from yfinance for {material}: {str(e)}")
            return []
    
    def _fetch_from_commodities_api(self, material: str, start_date: str, end_date: str) -> List[Dict[str, Any]]:
        """
        Fetch raw material data from Commodities-API.
        
        Args:
            material: The raw material to fetch data for
            start_date: Start date in YYYY-MM-DD format
            end_date: End date in YYYY-MM-DD format
            
        Returns:
            List of price data points
        """
        # Only proceed if we have an API key
        if not self.commodities_api_key:
            return []
        
        # Map raw material to symbol used by Commodities-API
        material_map = {
            "iron_ore": "IRON",
            "coal": "COAL",
            "copper_ore": "COPPER",
            "gold_ore": "XAU",
            "silver_ore": "XAG",
            "crude_oil": "BRENT",
            "natural_gas": "NG"
        }
        
        symbol = material_map.get(material.lower())
        if not symbol:
            logger.warning(f"No Commodities-API symbol for raw material: {material}")
            return []
        
        # Construct API URL
        base_url = "https://commodities-api.com/api/timeseries"
        params = {
            "access_key": self.commodities_api_key,
            "start_date": start_date,
            "end_date": end_date,
            "base": "USD",
            "symbols": symbol
        }
        
        # Make API request
        try:
            response = requests.get(base_url, params=params)
            data = response.json()
            
            if data.get("success"):
                rates = data.get("rates", {})
                result = []
                
                for date, rate_data in rates.items():
                    price = 1 / rate_data.get(symbol, 1)  # Convert rate to price
                    result.append({
                        "date": date,
                        "price": price
                    })
                
                return result
            else:
                logger.error(f"Commodities-API error: {data.get('error', {}).get('info')}")
                return []
        except Exception as e:
            logger.error(f"Error fetching from Commodities-API for {material}: {str(e)}")
            return []
    


# Create a singleton instance
raw_material_agent = RawMaterialAgent()

def fetch_raw_material_data(commodity: str, date_range: Dict[str, str]) -> Dict[str, Any]:
    """
    Fetch raw material data for a commodity.
    
    Args:
        commodity: The commodity to fetch raw material data for
        date_range: Dictionary with 'start' and 'end' dates
        
    Returns:
        Dictionary containing raw material price data and metadata
    """
    return raw_material_agent.fetch_data(
        commodity=commodity,
        start_date=date_range["start"],
        end_date=date_range["end"]
    )
