"""
Explainability Agent for the Commodity Price Predictor.
This module is responsible for computing feature importance and generating natural language summaries.
"""
import logging
from datetime import datetime
from typing import Dict, Any, List, Optional

import numpy as np
import pandas as pd
import shap
from sklearn.ensemble import RandomForestRegressor

# Configure logging
logger = logging.getLogger(__name__)

class ExplainabilityAgent:
    """Agent for explaining model predictions."""
    
    def __init__(self):
        """Initialize the Explainability Agent."""
        logger.info("Explainability Agent initialized")
    
    def generate_explanations(self, features: Dict[str, Any], predictions: Dict[str, Any]) -> Dict[str, Any]:
        """
        Generate explanations for model predictions.
        
        Args:
            features: Processed features from the Feature Engineering Agent
            predictions: Price forecasts from the Prediction Agent
            
        Returns:
            Dictionary containing feature importance and natural language explanations
        """
        logger.info("Generating explanations for predictions")
        
        try:
            # Convert features to DataFrame
            feature_df = self._convert_features_to_df(features)
            
            if feature_df.empty:
                logger.error("Feature data is empty, cannot generate explanations")
                return {
                    "feature_importance": [],
                    "narrative": "Unable to generate explanations due to missing feature data.",
                    "metadata": {
                        "explanation_method": "none",
                        "confidence": "none"
                    }
                }
            
            # Calculate feature importance
            importance = self._calculate_feature_importance(feature_df)
            
            # Generate narrative explanation
            narrative = self._generate_narrative(importance, predictions)
            
            # Format the response
            return {
                "feature_importance": importance,
                "narrative": narrative,
                "metadata": {
                    "explanation_method": "SHAP + Random Forest",
                    "confidence": "medium",
                    "last_updated": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                }
            }
        except Exception as e:
            logger.error(f"Error generating explanations: {str(e)}")
            raise
    
    def _convert_features_to_df(self, features: Dict[str, Any]) -> pd.DataFrame:
        """
        Convert feature dictionary to pandas DataFrame.
        
        Args:
            features: Processed features from the Feature Engineering Agent
            
        Returns:
            DataFrame with features
        """
        try:
            # Extract processed data
            processed_data = features.get("processed_data", {})
            
            # If no processed data, return empty DataFrame
            if not processed_data:
                return pd.DataFrame()
            
            # Get dates
            dates = processed_data.get("dates", [])
            
            # Create DataFrame
            data = {}
            for key, values in processed_data.items():
                if key != "dates":
                    data[key] = values
            
            df = pd.DataFrame(data)
            
            # Set index to dates
            if dates:
                df.index = pd.to_datetime(dates)
            
            return df
        except Exception as e:
            logger.error(f"Error converting features to DataFrame: {str(e)}")
            # Return empty DataFrame if there's an error
            return pd.DataFrame()
    
    def _calculate_feature_importance(self, df: pd.DataFrame) -> List[Dict[str, Any]]:
        """
        Calculate feature importance using SHAP values and Random Forest.
        
        Args:
            df: DataFrame with features
            
        Returns:
            List of feature importance dictionaries
        """
        try:
            # Make a copy to avoid modifying the original
            data = df.copy()
            
            # Target variable is the price
            if "price" not in data.columns:
                logger.error("No price column found in feature data")
                return []
            
            # Separate features and target
            y = data["price"].values
            X = data.drop(columns=["price"])
            
            # Train a Random Forest model
            model = RandomForestRegressor(n_estimators=100, random_state=42)
            model.fit(X, y)
            
            # Get feature importance from the model
            rf_importance = model.feature_importances_
            
            # Try to use SHAP for more detailed explanations
            try:
                # Create a SHAP explainer
                explainer = shap.TreeExplainer(model)
                
                # Calculate SHAP values
                shap_values = explainer.shap_values(X)
                
                # Get mean absolute SHAP values for each feature
                shap_importance = np.abs(shap_values).mean(axis=0)
                
                # Normalize to sum to 1
                shap_importance = shap_importance / shap_importance.sum()
                
                # Determine direction of impact
                mean_shap_values = shap_values.mean(axis=0)
                directions = ["positive" if val > 0 else "negative" for val in mean_shap_values]
                
                # Use SHAP importance
                importance_values = shap_importance
                method = "SHAP"
            except Exception as e:
                logger.warning(f"Error calculating SHAP values: {str(e)}. Using Random Forest importance instead.")
                
                # Use Random Forest importance
                importance_values = rf_importance
                
                # Normalize to sum to 1
                importance_values = importance_values / importance_values.sum()
                
                # Determine direction based on correlation with target
                directions = []
                for col in X.columns:
                    corr = np.corrcoef(X[col], y)[0, 1]
                    directions.append("positive" if corr > 0 else "negative")
                
                method = "Random Forest"
            
            # Create feature importance list
            feature_importance = []
            for i, col in enumerate(X.columns):
                feature_importance.append({
                    "feature": col,
                    "importance": round(float(importance_values[i]), 3),
                    "direction": directions[i]
                })
            
            # Sort by importance (descending)
            feature_importance.sort(key=lambda x: x["importance"], reverse=True)
            
            # Take top 10 features
            return feature_importance[:10]
        except Exception as e:
            logger.error(f"Error calculating feature importance: {str(e)}")
            return []
    
    def _generate_narrative(self, importance: List[Dict[str, Any]], predictions: Dict[str, Any]) -> str:
        """
        Generate a natural language explanation of the predictions.
        
        Args:
            importance: List of feature importance dictionaries
            predictions: Price forecasts from the Prediction Agent
            
        Returns:
            Natural language explanation
        """
        try:
            # Extract forecast data
            forecast = predictions.get("forecast", [])
            
            if not forecast or not importance:
                return "Insufficient data to generate an explanation."
            
            # Determine price trend
            first_price = forecast[0]["price"]
            last_price = forecast[-1]["price"]
            
            if last_price > first_price:
                trend = "increase"
                trend_pct = (last_price - first_price) / first_price * 100
            elif last_price < first_price:
                trend = "decrease"
                trend_pct = (first_price - last_price) / first_price * 100
            else:
                trend = "remain stable"
                trend_pct = 0
            
            # Get top 3 factors
            top_factors = importance[:3]
            
            # Generate narrative
            narrative = f"The forecast indicates that prices will {trend} by approximately {trend_pct:.1f}% over the next {len(forecast)} days. "
            
            # Add information about the top factors
            narrative += "The most significant factors influencing this forecast are:\n\n"
            
            for i, factor in enumerate(top_factors):
                feature = factor["feature"]
                direction = factor["direction"]
                impact = "upward" if direction == "positive" else "downward"
                
                # Make feature names more readable
                feature_name = feature.replace("_", " ").title()
                
                narrative += f"{i+1}. {feature_name}: Exerting {impact} pressure on prices (importance: {factor['importance']:.2f})\n"
            
            # Add a summary sentence
            positive_factors = [f for f in top_factors if f["direction"] == "positive"]
            negative_factors = [f for f in top_factors if f["direction"] == "negative"]
            
            if positive_factors and negative_factors:
                narrative += "\nWhile factors like "
                narrative += ", ".join([f["feature"].replace("_", " ").title() for f in positive_factors])
                narrative += " are pushing prices up, "
                narrative += ", ".join([f["feature"].replace("_", " ").title() for f in negative_factors])
                narrative += " are exerting downward pressure."
            elif positive_factors:
                narrative += "\nThe forecast is primarily driven by positive factors such as "
                narrative += ", ".join([f["feature"].replace("_", " ").title() for f in positive_factors])
                narrative += "."
            elif negative_factors:
                narrative += "\nThe forecast is primarily driven by negative factors such as "
                narrative += ", ".join([f["feature"].replace("_", " ").title() for f in negative_factors])
                narrative += "."
            
            # Add confidence information
            first_confidence = forecast[0]["upper_bound"] - forecast[0]["lower_bound"]
            last_confidence = forecast[-1]["upper_bound"] - forecast[-1]["lower_bound"]
            avg_confidence = (first_confidence + last_confidence) / 2
            
            if avg_confidence / first_price < 0.05:
                confidence = "high"
            elif avg_confidence / first_price < 0.15:
                confidence = "moderate"
            else:
                confidence = "low"
            
            narrative += f"\n\nThe model has {confidence} confidence in this forecast, with an average confidence interval of ±{avg_confidence:.2f}."
            
            return narrative
        except Exception as e:
            logger.error(f"Error generating narrative: {str(e)}")
            return "Unable to generate an explanation due to an error."

# Create a singleton instance
explainability_agent = ExplainabilityAgent()

def generate_explanations(features: Dict[str, Any], predictions: Dict[str, Any]) -> Dict[str, Any]:
    """
    Generate explanations for predictions.
    
    Args:
        features: Processed features from the Feature Engineering Agent
        predictions: Price forecasts from the Prediction Agent
        
    Returns:
        Dictionary containing feature importance and natural language explanations
    """
    return explainability_agent.generate_explanations(
        features=features,
        predictions=predictions
    )
