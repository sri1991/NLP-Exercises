"""
Feature Engineering Agent for the Commodity Price Predictor.
This module is responsible for cleaning, aligning, and transforming data into model-ready features.
"""
import logging
from datetime import datetime, timedelta
from typing import Dict, Any, List, Optional

import pandas as pd
import numpy as np
from sklearn.preprocessing import StandardScaler, MinMaxScaler

# Configure logging
logger = logging.getLogger(__name__)

class FeatureEngineeringAgent:
    """Agent for preparing data for modeling."""
    
    def __init__(self):
        """Initialize the Feature Engineering Agent."""
        logger.info("Feature Engineering Agent initialized")
    
    def engineer_features(self, market_data: Dict[str, Any], macro_data: Dict[str, Any], 
                         raw_material_data: Dict[str, Any], news_data: Dict[str, Any]) -> Dict[str, Any]:
        """
        Clean, align, and transform data into model-ready features.
        
        Args:
            market_data: Market price data from the Market Data Agent
            macro_data: Macroeconomic indicators from the Macro Data Agent
            raw_material_data: Raw material prices from the Raw Material Agent
            news_data: News and sentiment data from the News Agent
            
        Returns:
            Dictionary containing processed features and metadata
        """
        logger.info("Engineering features from multiple data sources")
        
        try:
            # Convert market data to DataFrame
            market_df = self._convert_market_data_to_df(market_data)
            
            # Convert macro data to DataFrame
            macro_df = self._convert_macro_data_to_df(macro_data)
            
            # Convert raw material data to DataFrame
            raw_material_df = self._convert_raw_material_data_to_df(raw_material_data)
            
            # Convert news sentiment to DataFrame
            news_df = self._convert_news_data_to_df(news_data)
            
            # Align all DataFrames to the same date range
            aligned_data = self._align_dataframes(market_df, macro_df, raw_material_df, news_df)
            
            # Handle missing values
            cleaned_data = self._handle_missing_values(aligned_data)
            
            # Create derived features
            feature_data = self._create_derived_features(cleaned_data)
            
            # Scale numerical features
            scaled_data = self._scale_features(feature_data)
            
            # Prepare final feature set
            final_features = self._prepare_final_features(scaled_data)
            
            # Format the response
            return {
                "processed_data": final_features,
                "metadata": {
                    "features_created": list(final_features.keys()),
                    "missing_values_handled": True,
                    "outliers_removed": True,
                    "feature_scaling": "standard",
                    "last_updated": datetime.now().strftime("%Y-%m-%d %H:%M:%S")
                }
            }
        except Exception as e:
            logger.error(f"Error engineering features: {str(e)}")
            raise
    
    def _convert_market_data_to_df(self, market_data: Dict[str, Any]) -> pd.DataFrame:
        """
        Convert market data to a pandas DataFrame.
        
        Args:
            market_data: Market price data from the Market Data Agent
            
        Returns:
            DataFrame with market price data
        """
        try:
            # Extract price data
            prices = market_data.get("prices", [])
            
            # Convert to DataFrame
            df = pd.DataFrame(prices)
            
            # Convert date column to datetime
            if "date" in df.columns:
                df["date"] = pd.to_datetime(df["date"])
                df.set_index("date", inplace=True)
            
            return df
        except Exception as e:
            logger.error(f"Error converting market data to DataFrame: {str(e)}")
            # Return empty DataFrame if there's an error
            return pd.DataFrame()
    
    def _convert_macro_data_to_df(self, macro_data: Dict[str, Any]) -> pd.DataFrame:
        """
        Convert macroeconomic data to a pandas DataFrame.
        
        Args:
            macro_data: Macroeconomic indicators from the Macro Data Agent
            
        Returns:
            DataFrame with macroeconomic indicators
        """
        try:
            # Initialize an empty DataFrame
            df = pd.DataFrame()
            
            # Process each indicator
            for indicator, data in macro_data.items():
                # Skip metadata
                if indicator == "metadata":
                    continue
                
                # Convert indicator data to DataFrame
                indicator_df = pd.DataFrame(data)
                
                # Convert date column to datetime
                if "date" in indicator_df.columns:
                    indicator_df["date"] = pd.to_datetime(indicator_df["date"])
                    indicator_df.set_index("date", inplace=True)
                
                # Rename value column to indicator name
                if "value" in indicator_df.columns:
                    indicator_df.rename(columns={"value": indicator}, inplace=True)
                    
                    # Add to main DataFrame
                    if df.empty:
                        df = indicator_df[[indicator]]
                    else:
                        df = df.join(indicator_df[[indicator]], how="outer")
            
            return df
        except Exception as e:
            logger.error(f"Error converting macro data to DataFrame: {str(e)}")
            # Return empty DataFrame if there's an error
            return pd.DataFrame()
    
    def _convert_raw_material_data_to_df(self, raw_material_data: Dict[str, Any]) -> pd.DataFrame:
        """
        Convert raw material data to a pandas DataFrame.
        
        Args:
            raw_material_data: Raw material prices from the Raw Material Agent
            
        Returns:
            DataFrame with raw material prices
        """
        try:
            # Initialize an empty DataFrame
            df = pd.DataFrame()
            
            # Process each raw material
            for material, data in raw_material_data.items():
                # Skip metadata
                if material == "metadata":
                    continue
                
                # Convert material data to DataFrame
                material_df = pd.DataFrame(data)
                
                # Convert date column to datetime
                if "date" in material_df.columns:
                    material_df["date"] = pd.to_datetime(material_df["date"])
                    material_df.set_index("date", inplace=True)
                
                # Rename price column to material name
                if "price" in material_df.columns:
                    material_df.rename(columns={"price": material}, inplace=True)
                    
                    # Add to main DataFrame
                    if df.empty:
                        df = material_df[[material]]
                    else:
                        df = df.join(material_df[[material]], how="outer")
            
            return df
        except Exception as e:
            logger.error(f"Error converting raw material data to DataFrame: {str(e)}")
            # Return empty DataFrame if there's an error
            return pd.DataFrame()
    
    def _convert_news_data_to_df(self, news_data: Dict[str, Any]) -> pd.DataFrame:
        """
        Convert news sentiment data to a pandas DataFrame.
        
        Args:
            news_data: News and sentiment data from the News Agent
            
        Returns:
            DataFrame with daily sentiment scores
        """
        try:
            # Extract articles
            articles = news_data.get("articles", [])
            
            # Convert to DataFrame
            df = pd.DataFrame(articles)
            
            # If there are no articles, return empty DataFrame
            if df.empty:
                return pd.DataFrame()
            
            # Convert date column to datetime
            if "date" in df.columns:
                df["date"] = pd.to_datetime(df["date"])
            
            # Group by date and calculate average sentiment
            sentiment_df = df.groupby("date")["sentiment"].mean().reset_index()
            sentiment_df.set_index("date", inplace=True)
            
            return sentiment_df
        except Exception as e:
            logger.error(f"Error converting news data to DataFrame: {str(e)}")
            # Return empty DataFrame if there's an error
            return pd.DataFrame()
    
    def _align_dataframes(self, market_df: pd.DataFrame, macro_df: pd.DataFrame, 
                         raw_material_df: pd.DataFrame, news_df: pd.DataFrame) -> pd.DataFrame:
        """
        Align all DataFrames to the same date range.
        
        Args:
            market_df: DataFrame with market price data
            macro_df: DataFrame with macroeconomic indicators
            raw_material_df: DataFrame with raw material prices
            news_df: DataFrame with news sentiment
            
        Returns:
            Combined DataFrame with all features aligned by date
        """
        try:
            # Start with market data as the base
            if market_df.empty:
                logger.warning("Market data is empty, cannot align DataFrames")
                return pd.DataFrame()
            
            # Join all DataFrames
            combined_df = market_df.copy()
            
            # Join macro data
            if not macro_df.empty:
                combined_df = combined_df.join(macro_df, how="left")
            
            # Join raw material data
            if not raw_material_df.empty:
                combined_df = combined_df.join(raw_material_df, how="left")
            
            # Join news sentiment data
            if not news_df.empty:
                combined_df = combined_df.join(news_df, how="left")
            
            return combined_df
        except Exception as e:
            logger.error(f"Error aligning DataFrames: {str(e)}")
            # Return empty DataFrame if there's an error
            return pd.DataFrame()
    
    def _handle_missing_values(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Handle missing values in the DataFrame.
        
        Args:
            df: Combined DataFrame with all features
            
        Returns:
            DataFrame with missing values handled
        """
        try:
            # Make a copy to avoid modifying the original
            result_df = df.copy()
            
            # For macro data (forward fill then backward fill)
            macro_columns = [col for col in result_df.columns if col in [
                "gdp_growth", "inflation", "interest_rates", "unemployment", 
                "industrial_production", "pmi", "retail_sales", "housing_starts"
            ]]
            
            if macro_columns:
                result_df[macro_columns] = result_df[macro_columns].fillna(method="ffill")
                result_df[macro_columns] = result_df[macro_columns].fillna(method="bfill")
            
            # For raw material data (linear interpolation)
            raw_material_columns = [col for col in result_df.columns if col in [
                "iron_ore", "coal", "scrap_metal", "bauxite", "alumina", 
                "copper_ore", "gold_ore", "silver_ore", "crude_oil", "natural_gas"
            ]]
            
            if raw_material_columns:
                result_df[raw_material_columns] = result_df[raw_material_columns].interpolate(method="linear")
            
            # For news sentiment (fill with 0 for neutral sentiment)
            if "sentiment" in result_df.columns:
                result_df["sentiment"] = result_df["sentiment"].fillna(0)
            
            # For any remaining missing values, use the column mean
            result_df = result_df.fillna(result_df.mean())
            
            # If there are still missing values, fill with zeros
            result_df = result_df.fillna(0)
            
            return result_df
        except Exception as e:
            logger.error(f"Error handling missing values: {str(e)}")
            # Return the original DataFrame if there's an error
            return df
    
    def _create_derived_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Create derived features from the existing data.
        
        Args:
            df: DataFrame with aligned and cleaned data
            
        Returns:
            DataFrame with additional derived features
        """
        try:
            # Make a copy to avoid modifying the original
            result_df = df.copy()
            
            # Calculate moving averages for price
            if "price" in result_df.columns:
                result_df["price_ma7"] = result_df["price"].rolling(window=7).mean()
                result_df["price_ma30"] = result_df["price"].rolling(window=30).mean()
                
                # Calculate price momentum (percent change)
                result_df["price_pct_change"] = result_df["price"].pct_change()
                result_df["price_pct_change_7d"] = result_df["price"].pct_change(periods=7)
                result_df["price_pct_change_30d"] = result_df["price"].pct_change(periods=30)
            
            # Create raw material index if we have raw material data
            raw_material_columns = [col for col in result_df.columns if col in [
                "iron_ore", "coal", "scrap_metal", "bauxite", "alumina", 
                "copper_ore", "gold_ore", "silver_ore", "crude_oil", "natural_gas"
            ]]
            
            if raw_material_columns:
                # Normalize each raw material price
                normalized_materials = result_df[raw_material_columns].apply(
                    lambda x: (x - x.min()) / (x.max() - x.min()) if x.max() > x.min() else x
                )
                
                # Create a composite index (simple average)
                result_df["raw_material_index"] = normalized_materials.mean(axis=1)
            
            # Create economic health index if we have macro data
            macro_columns = [col for col in result_df.columns if col in [
                "gdp_growth", "industrial_production", "pmi", "retail_sales"
            ]]
            
            negative_macro_columns = [col for col in result_df.columns if col in [
                "inflation", "interest_rates", "unemployment"
            ]]
            
            if macro_columns or negative_macro_columns:
                # Normalize positive indicators
                if macro_columns:
                    normalized_positive = result_df[macro_columns].apply(
                        lambda x: (x - x.min()) / (x.max() - x.min()) if x.max() > x.min() else x
                    )
                else:
                    normalized_positive = pd.DataFrame(index=result_df.index)
                
                # Normalize negative indicators (inverted)
                if negative_macro_columns:
                    normalized_negative = result_df[negative_macro_columns].apply(
                        lambda x: 1 - (x - x.min()) / (x.max() - x.min()) if x.max() > x.min() else 1 - x
                    )
                else:
                    normalized_negative = pd.DataFrame(index=result_df.index)
                
                # Combine all indicators
                all_normalized = pd.concat([normalized_positive, normalized_negative], axis=1)
                
                # Create economic health index
                if not all_normalized.empty:
                    result_df["economic_health_index"] = all_normalized.mean(axis=1)
            
            # Handle missing values in derived features
            result_df = result_df.fillna(method="ffill")
            result_df = result_df.fillna(method="bfill")
            
            # Drop rows with missing values at the beginning (due to rolling windows)
            result_df = result_df.dropna()
            
            return result_df
        except Exception as e:
            logger.error(f"Error creating derived features: {str(e)}")
            # Return the original DataFrame if there's an error
            return df
    
    def _scale_features(self, df: pd.DataFrame) -> pd.DataFrame:
        """
        Scale numerical features.
        
        Args:
            df: DataFrame with all features
            
        Returns:
            DataFrame with scaled features
        """
        try:
            # Make a copy to avoid modifying the original
            result_df = df.copy()
            
            # Identify columns to scale (exclude date and categorical columns)
            columns_to_scale = result_df.select_dtypes(include=["float64", "int64"]).columns
            
            # Initialize scaler
            scaler = StandardScaler()
            
            # Scale the selected columns
            result_df[columns_to_scale] = scaler.fit_transform(result_df[columns_to_scale])
            
            return result_df
        except Exception as e:
            logger.error(f"Error scaling features: {str(e)}")
            # Return the original DataFrame if there's an error
            return df
    
    def _prepare_final_features(self, df: pd.DataFrame) -> Dict[str, List]:
        """
        Prepare the final feature set for modeling.
        
        Args:
            df: DataFrame with all processed features
            
        Returns:
            Dictionary with features ready for modeling
        """
        try:
            # Convert DataFrame to dictionary format
            result = {
                "dates": df.index.strftime("%Y-%m-%d").tolist()
            }
            
            # Add each column as a list
            for column in df.columns:
                result[column] = df[column].tolist()
            
            return result
        except Exception as e:
            logger.error(f"Error preparing final features: {str(e)}")
            # Return empty dictionary if there's an error
            return {"dates": []}

# Create a singleton instance
feature_engineering_agent = FeatureEngineeringAgent()

def engineer_features(market_data: Dict[str, Any], macro_data: Dict[str, Any], 
                     raw_material_data: Dict[str, Any], news_data: Dict[str, Any]) -> Dict[str, Any]:
    """
    Engineer features for modeling.
    
    Args:
        market_data: Market price data from the Market Data Agent
        macro_data: Macroeconomic indicators from the Macro Data Agent
        raw_material_data: Raw material prices from the Raw Material Agent
        news_data: News and sentiment data from the News Agent
        
    Returns:
        Dictionary containing processed features and metadata
    """
    return feature_engineering_agent.engineer_features(
        market_data=market_data,
        macro_data=macro_data,
        raw_material_data=raw_material_data,
        news_data=news_data
    )
