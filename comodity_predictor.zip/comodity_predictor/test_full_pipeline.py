"""
Test script for the full commodity price prediction pipeline.
This will run the complete workflow with all agents using real-time data.
"""
import logging
import os
from datetime import datetime, timedelta
from dotenv import load_dotenv

from orchestrator.graph import run_prediction_workflow

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)

def main():
    """Test the full commodity price prediction pipeline."""
    # Check if required API keys are set
    fred_api_key = os.getenv("FRED_API_KEY")
    newsapi_key = os.getenv("NEWSAPI_KEY")
    commodities_api_key = os.getenv("COMMODITIES_API_KEY")
    groq_api_key = os.getenv("GROQ_API_KEY")
    
    logger.info("Checking API keys...")
    if not fred_api_key:
        logger.warning("FRED_API_KEY is not set. Macro data agent will fail.")
    if not newsapi_key:
        logger.warning("NEWSAPI_KEY is not set. News agent will fail.")
    if not commodities_api_key:
        logger.warning("COMMODITIES_API_KEY is not set. Alternative price sources will not be available.")
    if not groq_api_key:
        logger.warning("GROQ_API_KEY is not set. LLM-based analysis may be limited.")
    
    # Define test parameters
    commodity = "gold"  # Use gold as it's well-supported by yfinance
    days_back = 180     # Use 6 months of historical data
    forecast_days = 30  # Forecast for the next 30 days
    
    logger.info(f"Running full prediction workflow for {commodity} with {days_back} days of history")
    
    try:
        # Run the prediction workflow
        result = run_prediction_workflow(
            commodity=commodity,
            days_back=days_back,
            forecast_days=forecast_days
        )
        
        # Print the report summary
        report = result.get("report", {})
        
        logger.info(f"Prediction workflow completed successfully for {commodity}")
        logger.info(f"Current price: {report.get('current_price')}")
        
        # Print prediction summary
        predictions = report.get("predictions", [])
        if predictions:
            first_pred = predictions[0]
            last_pred = predictions[-1]
            logger.info(f"Forecast: {len(predictions)} days from {first_pred.get('date')} to {last_pred.get('date')}")
            logger.info(f"Starting price: {first_pred.get('price')}, Ending price: {last_pred.get('price')}")
            
            # Calculate percentage change
            start_price = first_pred.get('price', 0)
            end_price = last_pred.get('price', 0)
            if start_price > 0:
                pct_change = (end_price - start_price) / start_price * 100
                logger.info(f"Percentage change: {pct_change:.2f}%")
        
        # Print feature importance
        feature_importance = report.get("feature_importance", [])
        if feature_importance:
            logger.info("Top factors influencing the prediction:")
            for i, factor in enumerate(feature_importance[:3]):  # Top 3 factors
                logger.info(f"{i+1}. {factor.get('feature')}: {factor.get('importance'):.4f} ({factor.get('direction')})")
        
        # Print explanation
        explanation = report.get("explanation", "")
        if explanation:
            logger.info("Explanation summary:")
            # Print first 200 characters of explanation
            logger.info(f"{explanation[:200]}...")
        
        return result
        
    except Exception as e:
        logger.error(f"Error running prediction workflow: {str(e)}")
        return None

if __name__ == "__main__":
    main()
