"""
Test script for the news agent with real-time data only.
"""
import logging
import os
from datetime import datetime, timedelta
from agents.news import fetch_news_data
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)

def main():
    """Test the news agent with real-time data only."""
    # Define test parameters
    days_back = 7  # Last 7 days
    
    # Check if NewsAPI key is set
    newsapi_key = os.getenv("NEWSAPI_KEY")
    if not newsapi_key:
        logger.warning("NEWSAPI_KEY is not set. This test will fail as dummy data has been removed.")
    
    # Test with a few different commodities
    commodities = ["gold", "crude_oil"]
    
    for commodity in commodities:
        logger.info(f"Testing news agent for {commodity} from the past {days_back} days")
        
        try:
            # Call the news agent
            result = fetch_news_data(commodity, days_back)
            
            # Print the result metadata
            logger.info(f"News agent returned data with source: {result['metadata']['source']}")
            logger.info(f"Keywords used: {result['metadata']['keywords']}")
            logger.info(f"Overall sentiment: {result['overall_sentiment']}")
            
            # Check the articles
            articles = result.get("articles", [])
            article_count = len(articles)
            logger.info(f"Retrieved {article_count} news articles for {commodity}")
            
            if article_count > 0:
                logger.info(f"First article: {articles[0]['title']} (Sentiment: {articles[0]['sentiment']})")
                if article_count > 1:
                    logger.info(f"Last article: {articles[-1]['title']} (Sentiment: {articles[-1]['sentiment']})")
            
        except Exception as e:
            logger.error(f"Error testing news agent for {commodity}: {str(e)}")
            logger.info("This is expected if NEWSAPI_KEY is not set, as dummy data generation has been removed.")
    
    return "Testing complete"

if __name__ == "__main__":
    main()
