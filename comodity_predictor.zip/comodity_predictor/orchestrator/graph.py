"""
Agent graph orchestrator using LangGraph.
This module defines the agent workflow and connections between agents.
"""
import logging
import os
from datetime import datetime
from typing import Dict, Any, List, Annotated, TypedDict

from langchain.prompts import ChatPromptTemplate
from langchain_core.messages import SystemMessage, HumanMessage
from langchain_core.output_parsers import JsonOutputParser
from langchain_groq import ChatGroq
from langgraph.graph import StateGraph, END

# Configure logging
logger = logging.getLogger(__name__)

# Define state schema
class AgentState(TypedDict):
    """State schema for the agent graph."""
    commodity: str
    date_range: Dict[str, str]
    market_data: Dict[str, Any]
    macro_data: Dict[str, Any]
    raw_material_data: Dict[str, Any]
    news_data: Dict[str, Any]
    features: Dict[str, Any]
    predictions: Dict[str, Any]
    explanations: Dict[str, Any]
    report: Dict[str, Any]
    errors: List[str]
    current_agent: str

# Define agent nodes
def market_data_agent(state: AgentState) -> AgentState:
    """
    Fetches historical and current commodity prices.
    """
    logger.info(f"Market Data Agent processing {state['commodity']}")
    try:
        # Call the actual market data agent
        from agents.market_data import fetch_market_data
        
        market_data = fetch_market_data(
            commodity=state['commodity'], 
            date_range=state['date_range']
        )
        
        return {
            **state,
            "market_data": market_data,
            "current_agent": "market_data_agent"
        }
    except Exception as e:
        logger.error(f"Market Data Agent error: {str(e)}")
        return {
            **state,
            "errors": state["errors"] + [f"Market Data Agent error: {str(e)}"],
            "current_agent": "market_data_agent"
        }

def macro_data_agent(state: AgentState) -> AgentState:
    """
    Retrieves macroeconomic indicators.
    """
    logger.info("Macro Data Agent processing")
    try:
        # Call the actual macro data agent
        from agents.macro_data import fetch_macro_data
        
        macro_data = fetch_macro_data(
            date_range=state['date_range']
        )
        
        return {
            **state,
            "macro_data": macro_data,
            "current_agent": "macro_data_agent"
        }
    except Exception as e:
        logger.error(f"Macro Data Agent error: {str(e)}")
        return {
            **state,
            "errors": state["errors"] + [f"Macro Data Agent error: {str(e)}"],
            "current_agent": "macro_data_agent"
        }

def raw_material_agent(state: AgentState) -> AgentState:
    """
    Collects prices of raw materials.
    """
    logger.info("Raw Material Agent processing")
    try:
        # Call the actual raw material agent
        from agents.raw_material import fetch_raw_material_data
        
        raw_material_data = fetch_raw_material_data(
            commodity=state['commodity'],
            date_range=state['date_range']
        )
        
        return {
            **state,
            "raw_material_data": raw_material_data,
            "current_agent": "raw_material_agent"
        }
    except Exception as e:
        logger.error(f"Raw Material Agent error: {str(e)}")
        return {
            **state,
            "errors": state["errors"] + [f"Raw Material Agent error: {str(e)}"],
            "current_agent": "raw_material_agent"
        }

def news_agent(state: AgentState) -> AgentState:
    """
    Scrapes news and performs sentiment analysis.
    """
    logger.info(f"News Agent processing for {state['commodity']}")
    try:
        # Call the actual news agent
        from agents.news import fetch_news_data
        
        # Calculate days_back from date_range
        start_date = datetime.strptime(state['date_range']['start'], '%Y-%m-%d')
        end_date = datetime.strptime(state['date_range']['end'], '%Y-%m-%d')
        days_back = (end_date - start_date).days
        
        news_data = fetch_news_data(
            commodity=state['commodity'],
            days_back=days_back
        )
        
        return {
            **state,
            "news_data": news_data,
            "current_agent": "news_agent"
        }
    except Exception as e:
        logger.error(f"News Agent error: {str(e)}")
        return {
            **state,
            "errors": state["errors"] + [f"News Agent error: {str(e)}"],
            "current_agent": "news_agent"
        }

def feature_engineering_agent(state: AgentState) -> AgentState:
    """
    Cleans, aligns, and transforms data into model-ready features.
    """
    logger.info("Feature Engineering Agent processing")
    try:
        # Call the actual feature engineering agent
        from agents.feature_engineering import engineer_features
        
        features = engineer_features(
            market_data=state['market_data'], 
            macro_data=state['macro_data'], 
            raw_material_data=state['raw_material_data'], 
            news_data=state['news_data']
        )
        
        return {
            **state,
            "features": features,
            "current_agent": "feature_engineering_agent"
        }
    except Exception as e:
        logger.error(f"Feature Engineering Agent error: {str(e)}")
        return {
            **state,
            "errors": state["errors"] + [f"Feature Engineering Agent error: {str(e)}"],
            "current_agent": "feature_engineering_agent"
        }

def prediction_agent(state: AgentState) -> AgentState:
    """
    Runs time series or ML models to generate price forecasts.
    Uses Groq LLM to enhance predictions when possible.
    """
    logger.info("Prediction Agent processing")
    try:
        # Call the actual prediction agent
        from agents.prediction import generate_predictions
        
        # Pass news data and market data for LLM enhancement
        predictions = generate_predictions(
            features=state['features'],
            days=state.get('forecast_days', 60)
        )
        
        # Extract LLM explanation if available
        llm_explanation = predictions.get("metadata", {}).get("llm_explanation", "")
        
        # Update state with predictions and LLM explanation
        updated_state = {
            **state,
            "predictions": predictions,
            "current_agent": "prediction_agent"
        }
        
        # If we have LLM explanation, add it to the explanations
        if llm_explanation:
            logger.info("LLM explanation available from prediction agent")
            if "explanations" not in updated_state:
                updated_state["explanations"] = {}
            updated_state["explanations"]["llm_explanation"] = llm_explanation
        
        return updated_state
    except Exception as e:
        logger.error(f"Prediction Agent error: {str(e)}")
        return {
            **state,
            "errors": state["errors"] + [f"Prediction Agent error: {str(e)}"],
            "current_agent": "prediction_agent"
        }

def explainability_agent(state: AgentState) -> AgentState:
    """
    Computes feature importance and generates natural language summaries.
    """
    logger.info("Explainability Agent processing")
    try:
        # Call the actual explainability agent
        from agents.explainability import generate_explanations
        
        explanations = generate_explanations(
            features=state['features'],
            predictions=state['predictions']
        )
        
        return {
            **state,
            "explanations": explanations,
            "current_agent": "explainability_agent"
        }
    except Exception as e:
        logger.error(f"Explainability Agent error: {str(e)}")
        return {
            **state,
            "errors": state["errors"] + [f"Explainability Agent error: {str(e)}"],
            "current_agent": "explainability_agent"
        }

def reporting_agent(state: AgentState) -> AgentState:
    """
    Formats predictions, explanations, and visualizations for frontend delivery.
    """
    logger.info("Reporting Agent processing")
    try:
        # Call the actual reporting agent
        from agents.reporting import generate_report
        
        report = generate_report(state)
        
        return {
            **state,
            "report": report,
            "current_agent": "reporting_agent"
        }
    except Exception as e:
        logger.error(f"Reporting Agent error: {str(e)}")
        return {
            **state,
            "errors": state["errors"] + [f"Reporting Agent error: {str(e)}"],
            "current_agent": "reporting_agent"
        }

def should_continue(state: AgentState) -> str:
    """
    Determines whether to continue the workflow or end due to errors.
    """
    if state["errors"]:
        logger.warning(f"Workflow ending due to errors: {state['errors']}")
        return "end"
    return "continue"

def create_agent_graph() -> StateGraph:
    """
    Creates the agent workflow graph using LangGraph.
    """
    # Initialize the graph
    workflow = StateGraph(AgentState)
    
    # Add nodes for each agent
    workflow.add_node("market_data_agent", market_data_agent)
    workflow.add_node("macro_data_agent", macro_data_agent)
    workflow.add_node("raw_material_agent", raw_material_agent)
    workflow.add_node("news_agent", news_agent)
    workflow.add_node("feature_engineering_agent", feature_engineering_agent)
    workflow.add_node("prediction_agent", prediction_agent)
    workflow.add_node("explainability_agent", explainability_agent)
    workflow.add_node("reporting_agent", reporting_agent)
    
    # Define the workflow
    workflow.add_edge("market_data_agent", "macro_data_agent")
    workflow.add_edge("macro_data_agent", "raw_material_agent")
    workflow.add_edge("raw_material_agent", "news_agent")
    workflow.add_edge("news_agent", "feature_engineering_agent")
    workflow.add_edge("feature_engineering_agent", "prediction_agent")
    workflow.add_edge("prediction_agent", "explainability_agent")
    workflow.add_edge("explainability_agent", "reporting_agent")
    workflow.add_edge("reporting_agent", END)
    
    # Set the entry point
    workflow.set_entry_point("market_data_agent")
    
    # Compile the graph
    return workflow.compile()

def run_prediction_workflow(commodity: str, days_back: int = 365, forecast_days: int = 60) -> Dict[str, Any]:
    """
    Run the prediction workflow for a given commodity.
    
    Args:
        commodity: The commodity to predict prices for
        days_back: Number of days of historical data to use
        forecast_days: Number of days to forecast
        
    Returns:
        The final state containing the prediction report
    """
    # Create the initial state
    from datetime import datetime, timedelta
    
    today = datetime.now()
    start_date = (today - timedelta(days=days_back)).strftime("%Y-%m-%d")
    end_date = today.strftime("%Y-%m-%d")
    
    initial_state = {
        "commodity": commodity,
        "date_range": {
            "start": start_date,
            "end": end_date
        },
        "forecast_days": forecast_days,
        "market_data": {},
        "macro_data": {},
        "raw_material_data": {},
        "news_data": {},
        "features": {},
        "predictions": {},
        "explanations": {},
        "report": {},
        "errors": [],
        "current_agent": "none"
    }
    
    # Create and run the graph
    graph = create_agent_graph()
    final_state = graph.invoke(initial_state)
    
    return final_state
