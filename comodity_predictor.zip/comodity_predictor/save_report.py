"""
Utility script to run the prediction workflow and save the generated report to a file.
"""
import os
import json
import logging
from datetime import datetime, timedelta
import argparse

from dotenv import load_dotenv
from orchestrator.graph import run_prediction_workflow

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format='%(asctime)s - %(name)s - %(levelname)s - %(message)s'
)
logger = logging.getLogger(__name__)

def check_api_keys():
    """Check if required API keys are set."""
    required_keys = {
        "FRED_API_KEY": "FRED macroeconomic data",
        "NEWSAPI_KEY": "News data"
    }
    
    optional_keys = {
        "COMMODITIES_API_KEY": "Alternative price sources",
        "GROQ_API_KEY": "LLM-based analysis"
    }
    
    missing_required = []
    
    for key, description in required_keys.items():
        if not os.getenv(key):
            missing_required.append(f"{key} for {description}")
    
    for key, description in optional_keys.items():
        if not os.getenv(key):
            logger.warning(f"{key} is not set. {description} may be limited.")
    
    if missing_required:
        raise ValueError(f"Missing required API keys: {', '.join(missing_required)}")

def save_report_to_file(report, commodity, output_dir="reports"):
    """
    Save the generated report to a JSON file.
    
    Args:
        report: The report data to save
        commodity: The commodity name
        output_dir: Directory to save reports
    
    Returns:
        Path to the saved report file
    """
    # Create reports directory if it doesn't exist
    os.makedirs(output_dir, exist_ok=True)
    
    # Generate filename with timestamp
    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    filename = f"{commodity}_report_{timestamp}.json"
    filepath = os.path.join(output_dir, filename)
    
    # Save report as JSON
    with open(filepath, 'w') as f:
        json.dump(report, f, indent=2, default=str)
    
    logger.info(f"Report saved to {filepath}")
    return filepath

def main():
    """Run the prediction workflow and save the report."""
    # Parse command line arguments
    parser = argparse.ArgumentParser(description='Run commodity prediction and save report')
    parser.add_argument('--commodity', type=str, default='gold', 
                        help='Commodity to predict (default: gold)')
    parser.add_argument('--days-back', type=int, default=30, 
                        help='Days of historical data to use (default: 30)')
    parser.add_argument('--forecast-days', type=int, default=60, 
                        help='Number of days to forecast (default: 60)')
    parser.add_argument('--output-dir', type=str, default='reports', 
                        help='Directory to save reports (default: reports)')
    args = parser.parse_args()
    
    # Load environment variables
    load_dotenv()
    
    try:
        # Check for required API keys
        check_api_keys()
        
        logger.info(f"Running prediction workflow for {args.commodity} with {args.days_back} days of history")
        
        # Run the prediction workflow
        result = run_prediction_workflow(
            commodity=args.commodity,
            days_back=args.days_back,
            forecast_days=args.forecast_days
        )
        
        # Extract the final report
        report = result.get('report', {})
        
        # Add metadata to the report
        report['metadata'] = {
            'commodity': args.commodity,
            'days_back': args.days_back,
            'forecast_days': args.forecast_days,
            'run_timestamp': datetime.now().isoformat(),
        }
        
        # Save the report to a file
        filepath = save_report_to_file(report, args.commodity, args.output_dir)
        
        # Print summary information
        current_price = None
        if report.get('price_data') and report['price_data'].get('current_price'):
            current_price = report['price_data']['current_price']
        
        logger.info(f"Prediction workflow completed successfully for {args.commodity}")
        logger.info(f"Report saved to: {filepath}")
        logger.info(f"Current price: {current_price}")
        
        # Print forecast summary if available
        if report.get('forecast_summary'):
            logger.info(f"Forecast summary: {report['forecast_summary']}")
        
        # Print top factors if available
        if report.get('feature_importance') and isinstance(report['feature_importance'], list):
            logger.info("Top factors influencing the prediction:")
            for i, factor in enumerate(report['feature_importance'][:3], 1):
                direction = "positive" if factor.get('impact', 0) > 0 else "negative"
                logger.info(f"{i}. {factor.get('feature')}: {factor.get('importance'):.4f} ({direction})")
        
    except Exception as e:
        logger.error(f"Error running prediction workflow: {str(e)}")
        raise

if __name__ == "__main__":
    main()
