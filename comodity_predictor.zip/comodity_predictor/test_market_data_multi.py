"""
Test script for the market data agent with multiple commodities.
"""
import logging
from datetime import datetime, timedelta
from agents.market_data import fetch_market_data, COMMODITY_TICKERS

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)

def main():
    """Test the market data agent with multiple commodities."""
    # Define test parameters
    today = datetime.now()
    start_date = (today - timedelta(days=30)).strftime("%Y-%m-%d")
    end_date = today.strftime("%Y-%m-%d")
    
    date_range = {
        "start": start_date,
        "end": end_date
    }
    
    # Test a few different commodities
    commodities = ["gold", "silver", "crude_oil", "steel"]
    
    results = {}
    
    for commodity in commodities:
        logger.info(f"Testing market data agent for {commodity} from {start_date} to {end_date}")
        
        try:
            # Call the market data agent
            result = fetch_market_data(commodity, date_range)
            
            # Print the result
            data_points = len(result['prices']) if result.get('prices') else 0
            logger.info(f"{commodity}: Market data agent returned {data_points} data points")
            
            if data_points > 0:
                logger.info(f"{commodity}: First data point: {result['prices'][0]}")
                logger.info(f"{commodity}: Last data point: {result['prices'][-1]}")
                logger.info(f"{commodity}: Metadata: {result['metadata']}")
            else:
                logger.info(f"{commodity}: No data points returned")
            
            results[commodity] = result
        except Exception as e:
            logger.error(f"Error testing market data agent for {commodity}: {str(e)}")
            results[commodity] = {"error": str(e)}
    
    # Print summary
    logger.info("\nSummary of results:")
    for commodity, result in results.items():
        data_points = len(result.get('prices', [])) if not result.get('error') else 0
        if result.get('error'):
            logger.info(f"{commodity}: Error - {result['error']}")
        else:
            logger.info(f"{commodity}: {data_points} data points from {result['metadata']['source']}")
    
    return results

if __name__ == "__main__":
    main()
