"""
Test script for the macro data agent with real-time data only.
"""
import logging
import os
from datetime import datetime, timedelta
from agents.macro_data import fetch_macro_data
from dotenv import load_dotenv

# Load environment variables
load_dotenv()

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)

def main():
    """Test the macro data agent with real-time data only."""
    # Define test parameters
    today = datetime.now()
    start_date = (today - timedelta(days=365)).strftime("%Y-%m-%d")  # Last year
    end_date = today.strftime("%Y-%m-%d")
    
    date_range = {
        "start": start_date,
        "end": end_date
    }
    
    logger.info(f"Testing macro data agent from {start_date} to {end_date}")
    
    # Check if FRED API key is set
    fred_api_key = os.getenv("FRED_API_KEY")
    if not fred_api_key:
        logger.warning("FRED_API_KEY is not set. This test will fail as dummy data has been removed.")
    
    try:
        # Call the macro data agent
        result = fetch_macro_data(date_range)
        
        # Print the result
        logger.info(f"Macro data agent returned data with source: {result['metadata']['source']}")
        
        # Check each economic indicator
        for indicator, data in result.items():
            if indicator != "metadata":
                data_points = len(data)
                logger.info(f"Indicator '{indicator}': {data_points} data points")
                if data_points > 0:
                    logger.info(f"  First data point: {data[0]}")
                    logger.info(f"  Last data point: {data[-1]}")
        
        return result
    except Exception as e:
        logger.error(f"Error testing macro data agent: {str(e)}")
        logger.info("This is expected if FRED_API_KEY is not set, as dummy data generation has been removed.")
        return None

if __name__ == "__main__":
    main()
