"""
Test script for the market data agent with real-time data only.
"""
import logging
from datetime import datetime, timedelta
from agents.market_data import fetch_market_data

# Configure logging
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s - %(name)s - %(levelname)s - %(message)s",
)
logger = logging.getLogger(__name__)

def main():
    """Test the market data agent with real-time data only."""
    # Define test parameters
    today = datetime.now()
    start_date = (today - timedelta(days=30)).strftime("%Y-%m-%d")  # Last 30 days
    end_date = today.strftime("%Y-%m-%d")
    
    date_range = {
        "start": start_date,
        "end": end_date
    }
    
    # Test with a few different commodities
    commodities = ["gold", "silver", "crude_oil", "copper"]
    
    for commodity in commodities:
        logger.info(f"Testing market data agent for {commodity} from {start_date} to {end_date}")
        
        try:
            # Call the market data agent
            result = fetch_market_data(commodity, date_range)
            
            # Print the result
            logger.info(f"Market data agent returned data with source: {result['metadata']['source']}")
            
            # Check the price data
            prices = result.get("prices", [])
            data_points = len(prices)
            logger.info(f"Retrieved {data_points} data points for {commodity}")
            
            if data_points > 0:
                logger.info(f"First data point: {prices[0]}")
                logger.info(f"Last data point: {prices[-1]}")
            
        except Exception as e:
            logger.error(f"Error testing market data agent for {commodity}: {str(e)}")
    
    return "Testing complete"

if __name__ == "__main__":
    main()
